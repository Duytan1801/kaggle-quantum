#!/usr/bin/env python3
"""invsqrt_fc2_patch_h1c.py -- FC2 patch "h1c" for FC's g8 (own code): the higher-order stage H1' for any root split
m (nb = 17 - m folded bits of T: m 8 -> 9, m 7 -> 10), with the arithmetic of the R37 designer's integer reference
tools/r37_inv_40_ref.py (read as a model):
  T = y >> 9 (nb + 1 bits), L = y & 511, s = sign, Tf_i = T_i xor s (i < nb).
  A   = lin Tf - sum w_ij (Tf_i xor Tf_j)   half units, lin = 3 * 2^(nb - 9);
        w_ij = 3 * 2^(i+j-9) (i + j >= 9; w_45 = 2), 1 for i + j = 8 (unless in drop8), else 0
  cub = sum g_k P_k(Tf)  units, P_k = AND of folded bits;  h = (A + K2) >> 1 + (1 - 2 s) cub;  U = y + h + off.
Circuit: register R = [Gd, L_0..L_8, c0 (, c1, c2 if nc 3)] in half units (Gd = guard, fresh 0); every word is added /
subtracted into R by FC's adder A.add (narrow block + explicit undo), mod 2^len(R):
  lin      Tf at positions i + nb - 9 and i + nb - 8 (two adds)
  row j    pair parts of (i, j) as in-place literals x_ij = Tf_i xor Tf_j on T[i]: part 2 at i + j - 8,
           part 1 at i + j - 9; merged rows j (option merge): part 2 of row j + part 1 of row j + 1 as ONE word
           (e = Tf_j xor Tf_j+1; {0: e, i + j - 7: e OR x_ij}: R36's merge, OR temps)
  cubic    (1 - 2 s) g P = g (P xor s) - g s: the word {pos(g): P xor s} added; the -15 s units either as a word
           (subtracted) or (cubfold) as s at position 5 of the lowest merged word (-32 s) + two carry-ins s (+2 s)
  const    K2 + 2 off (half units) as carry-ins / borrow-ins ONE
Gd is the XOR of the position-0 literals (cleared by CNOTs). nc 1: C >> 1 = c1 + 2 c2 from FC2's threshold rule
(emit_chi, 17 ANDs) on the folded T before the increment; nc 3: in place. Then unfold, T += C; c1, c2 are
X-measured and the mirror's explicit undo rebuilds them by the rule on T' (repays the debts); c0 is held.
  cfg["h1c"] = {"nb": 10, "cub": [[g, [bits]], ...], "K2": 0, "off": -1, "drop8": [], "nc": 1, "merge": [5, 6, 7],
                "cubfold": 1}
  invsqrt_fc2_patch_h1c.py check SRC N CFG.json 'OVERRIDES'   model vs circuit (word, x, ancillas) on sampled inputs
"""
import json
import os
import sys

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

DEF = dict(nb=10, cub=[[4, [9]], [8, [9, 8]], [2, [9, 7]], [1, [9, 6]]], K2=0, off=-1, drop8=[], nc=3, merge=[],
           cubfold=0)


def opts(cfg):
    o = dict(DEF)
    o.update(cfg.get("h1c", {}))
    return o


def weights(o):
    """[(i, j, position)] of every pair part the stage subtracts (half units)."""
    nb = int(o["nb"])
    drop8 = {tuple(p) for p in o.get("drop8", [])}
    out = []
    for j in range(nb):
        for i in range(j):
            if i + j == 8:
                if (i, j) not in drop8:
                    out.append((i, j, 0))
            elif (i, j) == (4, 5):
                out.append((i, j, 1))
            elif i + j >= 9:
                out.append((i, j, i + j - 9))
                out.append((i, j, i + j - 8))
    return out


def active_parts(o):
    """weights(o) minus option drops: "dropparts" [[i, j, pos]] and "mlow" {j: imin} (merged row j starts at pair
    imin: part 2 of (i, j) and part 1 of (i, j + 1) for i < imin are dropped; both sit at position i + j - 8)."""
    drop = {tuple(int(t) for t in q) for q in o.get("dropparts", [])}
    for j, imin in (o.get("mlow") or {}).items():
        j, imin = int(j), int(imin)
        for i in range(imin):
            drop.add((i, j, i + j - 8))
            drop.add((i, j + 1, i + j - 8))
    return [q for q in weights(o) if q not in drop]


def table_prog(k, vals, nout=5):
    """F1's minand format program for the bits of vals[t] (t = k input bits z0..z(k-1), z0 lowest) from the ANF:
    every monomial of degree >= 2 an AND chain (shared prefixes); outputs = XOR of monomials (-1 = constant 1)."""
    n = k
    gates, gid = [], {}

    def prod(ms):                                      # ms: sorted tuple of input indices (len >= 2)
        if ms in gid:
            return gid[ms]
        left = ms[0] if len(ms) == 2 else prod(ms[:-1])
        gates.append({"left": [left], "right": [ms[-1]]})
        gid[ms] = n + len(gates) - 1
        return gid[ms]
    outs = []
    for bit in range(nout):
        anf = [(int(vals[t]) >> bit) & 1 for t in range(1 << k)]
        for b in range(k):
            for z in range(1 << k):
                if z >> b & 1:
                    anf[z] ^= anf[z ^ (1 << b)]
        terms = []
        for z in range(1 << k):
            if not anf[z]:
                continue
            ms = tuple(i for i in range(k) if z >> i & 1)
            if len(ms) == 0:
                terms.append(-1)
            elif len(ms) == 1:
                terms.append(ms[0])
            else:
                terms.append(prod(ms))
        outs.append(terms)
    return {"gates": gates, "outputs": outs}


_TABPROG = {"prog": None}


def emit_table(c, k, vals, zin, outs, uncompute=False):
    """outs ^= the table bits (outs zero, or holding the table when uncompute): F3's six_a programs when cfg h1c
    "cubprog" is "f3" (CUB8 at >= 5 temporaries, else the staged 11-AND form), a named F1-format program, or the
    trie."""
    if isinstance(_TABPROG["prog"], dict) and "acc" in _TABPROG["prog"]:   # F4: any program, accumulator form
        import invsqrt_fw_chiprog as CP
        return CP.emit_cub_auto_prog(c, list(zin), list(outs), _TABPROG["prog"]["acc"], uncompute=uncompute)
    if _TABPROG["prog"] == "f3":
        import invsqrt_fw_chiprog as CP
        return CP.emit_cub_auto(c, list(zin), list(outs), uncompute=uncompute)
    if isinstance(_TABPROG["prog"], list):             # staged [[bit, given, prog], ..] (R37 re-pricer's order file)
        import invsqrt_fw_chiprog as CP
        st = _TABPROG["prog"]
        k_ = 0
        for b_, given, prog in (reversed(st) if uncompute else st):
            k_ += CP.emit(c, prog, list(zin) + [outs[d] for d in given], [outs[b_]], max(1, c.cap - c.live))
        return k_
    if _TABPROG["prog"] is not None:
        import invsqrt_fw_chiprog as CP
        return CP.emit(c, _TABPROG["prog"], list(zin), list(outs), max(1, c.cap - c.live))
    return emit_table_trie(c, k, vals, zin, outs)


def emit_phase_cond(c, prog, ins, g):
    """(-1)^(g f(ins)), f = output 0 of an F1-format program, g a measured bit: a gate read by later gates is
    computed into a temporary by CCX if g (CANDC: 1/2 expected) and erased by measurement (CANDE: free); a gate read
    only by the output acts as CZ if g between its two factors (free); input / temporary terms as Z if g, the
    constant as NEG if g. Returns the number of conditioned ANDs."""
    n = len(ins)
    used = [False] * len(prog["gates"])
    for gt in prog["gates"]:
        for x in gt["left"] + gt["right"]:
            if x >= n:
                used[x - n] = True
    wire = {i: ins[i] for i in range(n)}

    def form(lst, other):
        cand = [x for x in lst if x not in other and x in wire]
        assert cand, ("no carrier", lst, other)
        car = cand[0]
        rest = [x for x in lst if x != car]
        for x in rest:
            c.cx(wire[x], wire[car])
        return car, rest

    def unform(car, rest):
        for x in reversed(rest):
            c.cx(wire[x], wire[car])

    def factors(j):
        gt = prog["gates"][j]
        cl, rl = form(gt["left"], gt["right"])
        cr, rr = form(gt["right"], gt["left"])
        return (cl, rl), (cr, rr)

    temps, k = [], 0
    for j in range(len(prog["gates"])):
        if not used[j]:
            continue
        (cl, rl), (cr, rr) = factors(j)
        t = c.alloc(1)[0]
        c.cand_compute(wire[cl], wire[cr], t, g)
        unform(cr, rr)
        unform(cl, rl)
        wire[n + j] = t
        temps.append(j)
        k += 1
    for x in prog["outputs"][0]:
        if x == -1:
            c.neg(g)
        elif x < n or used[x - n]:
            c.z(wire[x], g)
        else:
            (cl, rl), (cr, rr) = factors(x - n)
            c.cz(wire[cl], wire[cr], g)
            unform(cr, rr)
            unform(cl, rl)
    for j in reversed(temps):
        (cl, rl), (cr, rr) = factors(j)
        c.cand_erase(wire[cl], wire[cr], wire[n + j], g)
        unform(cr, rr)
        unform(cl, rl)
        c.free_([wire[n + j]])
        del wire[n + j]
    return k


def emit_table_trie(c, k, vals, zin, outs):
    """outs[bit] ^= bit of vals[t] (t on the wires zin, zin[0] lowest): depth-first over the trie of the ANF
    monomials: one AND per distinct prefix (computed, XORed into every output bit whose ANF holds it, its children
    done, erased free); at most k - 1 temporaries live; linear terms and the constant by CNOT / X."""
    nout = len(outs)
    anfs = []
    for bit in range(nout):
        a = [(int(vals[t]) >> bit) & 1 for t in range(1 << k)]
        for b in range(k):
            for z in range(1 << k):
                if z >> b & 1:
                    a[z] ^= a[z ^ (1 << b)]
        anfs.append(a)
    mons = {}
    for bit in range(nout):
        for z in range(1 << k):
            if anfs[bit][z]:
                mons.setdefault(tuple(i for i in range(k) if z >> i & 1), []).append(bit)
    for ms, bits in mons.items():                      # constant and linear terms
        if len(ms) == 0:
            for b_ in bits:
                c.x(outs[b_])
        elif len(ms) == 1:
            for b_ in bits:
                c.cx(zin[ms[0]], outs[b_])
    prefixes = set()
    for ms in mons:
        for L_ in range(2, len(ms) + 1):
            prefixes.add(ms[:L_])
    ands = [0]

    def leaf(ch):                                      # a leaf that would be the 4th live temporary: CCX instead
        return len(ch) >= 5 and not any(ch + (r,) in prefixes for r in range(ch[-1] + 1, k))

    def visit(pref, wire):
        for b_ in mons.get(pref, []):
            c.cx(wire, outs[b_])
        for q in range(pref[-1] + 1, k):
            ch = pref + (q,)
            if ch in prefixes:
                if leaf(ch):                           # a leaf: CCX into each output that holds it (no temporary)
                    for b_ in mons.get(ch, []):
                        c.ccx(wire, zin[q], outs[b_])
                        ands[0] += 1
                    continue
                t = c.and_compute(wire, zin[q])
                ands[0] += 1
                visit(ch, t)
                c.and_erase(wire, zin[q], t)
    for i in range(k):
        for q in range(i + 1, k):
            ch = (i, q)
            if ch in prefixes:
                t = c.and_compute(zin[i], zin[q])
                ands[0] += 1
                visit(ch, t)
                c.and_erase(zin[i], zin[q], t)
    return ands[0]


def form_literal(state, target, avoid):
    """a carrier wire holding the XOR of the folded bits in `target` (a frozenset) from the T wires' current values
    state {wire: (frozenset, neg)}: returns (pre ops, carrier) or None; the carrier is not in `avoid`."""
    ws = [w for w in state if w not in avoid]
    allw = list(state)
    for w in ws:                                       # one wire
        st, ng = state[w]
        if st == target:
            return ([("x", w)] if ng else []), w
    for w in ws:                                       # carrier + one more
        for v in allw:
            if v == w:
                continue
            if state[w][0] ^ state[v][0] == target:
                ng = state[w][1] ^ state[v][1]
                return ([("cx", v, w)] + ([("x", w)] if ng else [])), w
    for w in ws:                                       # carrier + two more
        for i, v in enumerate(allw):
            for u in allw[i + 1:]:
                if w in (v, u):
                    continue
                if state[w][0] ^ state[v][0] ^ state[u][0] == target:
                    ng = state[w][1] ^ state[v][1] ^ state[u][1]
                    return ([("cx", v, w), ("cx", u, w)] + ([("x", w)] if ng else [])), w
    return None


def _do(c, op, t=None):
    """one self-inverse op: ("x", w) or ("cx", a, b); the name "T" stands for the temporary t."""
    if op[0] == "x":
        c.x(t if op[1] == "T" else op[1])
    else:
        c.cx(op[1], t if op[2] == "T" else op[2])


class _Ands:
    """temporary ANDs with recorded erasure (measurement-based, 0 Toffolis), erased in reverse order."""
    def __init__(self, c):
        self.c, self.er = c, []

    def g(self, a, b, pre=(), post=()):
        c = self.c
        for op in pre:
            _do(c, op)
        t = c.and_compute(a, b)
        for op in reversed(pre):
            _do(c, op)
        for op in post:
            _do(c, op, t)

        def er():
            for op in reversed(post):
                _do(c, op, t)
            for op in pre:
                _do(c, op)
            c.and_erase(a, b, t)
            for op in reversed(pre):
                _do(c, op)
        self.er.append(er)
        return t

    def erase(self):
        for er in reversed(self.er):
            er()
        self.er = []


_CHI = {"mode": "fc2"}


def emit_chi(c, z, l0, l1, c0, out1, out2):
    """out1 ^= c1, out2 ^= c2, C >> 1 = c1 + 2 c2 by FC2's threshold rule (exact on all y of m 7 for DEF7, before
    and after T += C; tools/invsqrt_fc2_chi.py): z = the top 4 folded bits of T (z[0] LSB), l1 l0 = L''_8 L''_7,
      Chi = [z >= t0] + [z >= t1] + [z >= t2],  t0 = 6 + 3 c0 + l1 l0,  t1 = 11 + 2 c0 + (c0 ? l1 l0 : l1),
      t2 = c0 ? 16 : 14 + l1;  so c2 = [z >= t1] and c1 = the parity of the three.  17 ANDs, all erased free."""
    if _CHI["mode"] == "f3six":                                      # F3's exact six_a programs (4 + 3 ANDs)
        import invsqrt_fw_chiprog as CP
        CP.emit_staged(c, [z[0], z[1], z[2], z[3], l0, l1, c0], out1, out2, c.cap - c.live, spec="six_a")
        return
    if _CHI["mode"] == "f3six6":                                     # F3's joint six_a program (6 ANDs, <= 5 temps)
        import invsqrt_fw_chiprog as CP
        CP.emit(c, CP.CHI6_K6, [z[0], z[1], z[2], z[3], l0, l1, c0], [out1, out2], c.cap - c.live)
        return
    if _CHI["mode"] == "f3k5":                                       # F3's chooser: CHI6_K5 (5 ANDs at 5 temps),
        import invsqrt_fw_chiprog as CP                              # CHI6_K6, or the staged form
        CP.emit_chi6(c, z, l0, l1, c0, out1, out2, outs_zero=bool(_CHI.get("zero", True)))
        return
    z0, z1, z2, z3 = z
    a = _Ands(c)                                                     # i2 = NOT c0 z3 z2 z1 (z0 OR NOT l1) -> out1
    U1 = a.g(z3, z2)
    U2 = a.g(U1, z1)
    V = a.g(z0, l1, pre=[("x", z0)])                                 # NOT z0 AND l1 = NOT (z0 OR NOT l1)
    W = a.g(U2, V, pre=[("x", V)])
    c.x(c0)
    c.ccx(W, c0, out1)
    c.x(c0)
    a.erase()
    shP = _Ands(c)
    P = shP.g(l1, l0)                                                # p = l1 l0
    shG = _Ands(c)
    G = shG.g(c0, P, pre=[("cx", l1, P)], post=[("cx", l1, "T")])    # q = l1 xor c0 (p xor l1)
    a = _Ands(c)                                                     # i1 = carry of z + (q, c0^q, ~c0~q, 0) + 1
    K1 = a.g(z0, G, pre=[("x", z0), ("x", G)], post=[("x", "T")])    # z0 OR q
    K2 = a.g(z1, G, pre=[("cx", c0, G), ("cx", K1, z1), ("cx", K1, G)], post=[("cx", K1, "T")])  # MAJ(z1, c0^q, K1)
    Rr = a.g(c0, G, pre=[("x", c0), ("x", G)])                      # NOT c0 AND NOT q
    K3 = a.g(z2, Rr, pre=[("cx", K2, z2), ("cx", K2, Rr)], post=[("cx", K2, "T")])
    c.ccx(z3, K3, out2)                                              # out2 = i1 (fresh zero before)
    c.cx(out2, out1)
    a.erase()
    shG.erase()
    a = _Ands(c)                                                     # i0 = carry of z + (~(p^c0), c0~p, c0, ~c0) + 1
    J1 = a.g(z0, P, pre=[("cx", c0, P), ("x", z0)], post=[("x", "T")])   # z0 OR NOT (p xor c0)
    M = a.g(c0, P, pre=[("x", P)])                                   # c0 AND NOT p
    J2 = a.g(z1, M, pre=[("cx", J1, z1), ("cx", J1, M)], post=[("cx", J1, "T")])
    J3 = a.g(z2, c0, pre=[("cx", J2, z2), ("cx", J2, c0)], post=[("cx", J2, "T")])
    c.x(c0)                                                          # out1 ^= MAJ(z3, NOT c0, J3)
    c.cx(J3, z3)
    c.cx(J3, c0)
    c.ccx(z3, c0, out1)
    c.cx(J3, c0)
    c.cx(J3, z3)
    c.x(c0)
    c.cx(J3, out1)
    a.erase()
    shP.erase()


_MUXSPLIT = {"q": None}


def _mux_add(F8, c, T, R, s, nb, cubfold, s1=False, cin_w=None):   # I39-SLOT9 (inv_i39_patch_slot9.py)
    """FC2 mux (nb 10, after h1b's mux8): lin 1 + lin 2 - part 2 of row nb-1 as ONE add into R (11 wires, half
    units): with f = Tf_9 and Tl = Tf_0..8 the three words sum to f ? 8 Tl + 2 : 4 Tl (mod 2^11), i.e. the word
        {1: f, 2: NOT f AND Tl_0, p = 3..10: f ? Tl_(p-3) : Tl_(p-2)}   (+ cubfold: s at position 0, carry-in s).
    Forward: each mux bit one AND into a temporary made right before FC's narrow ripple reads it, erased after.
    Undo (explicit): Z2 = NOT f Tl_0, Z3 = f ? Tl_0 : Tl_1 (2 ANDs), Tl_1..8 rotated one place up under f
    (7 CSWAP: wire k = f ? Tl_(k-1) : Tl_k), FC's narrow undo generator, rotation back."""
    import invsqrt_fc_narrow as NW
    from invsqrt_fc2_patch_h1b import _fwd_stream
    assert nb == 10 and len(R) == 11
    f = T[9]
    hold = {}

    def plain(w):
        return (lambda: w, lambda: None)

    def mk2():
        c.x(f)
        t = c.and_compute(f, T[0])
        c.x(f)
        hold[2] = t
        return t

    def rl2():
        c.x(f)
        c.and_erase(f, T[0], hold.pop(2))
        c.x(f)

    def mkp(p):                                        # f ? Tl_(p-3) : Tl_(p-2) = b xor f (a xor b)
        def mk():
            a, b = T[p - 3], T[p - 2]
            c.cx(a, b)
            t = c.and_compute(f, b)
            c.cx(a, b)
            c.cx(b, t)
            hold[p] = t
            return t

        def rl():
            a, b = T[p - 3], T[p - 2]
            t = hold.pop(p)
            c.cx(b, t)
            c.cx(a, b)
            c.and_erase(f, b, t)
            c.cx(a, b)
        return mk, rl

    w0 = s if (cubfold and not s1) else None           # cubfold: +s here, the other +s is the cubic add's carry-in
    lits = [plain(w0), plain(f), (mk2, rl2)] + [mkp(p) for p in range(3, 11)]
    cin = cin_w                                        # I39-SLOT9 (inv_i39_patch_slot9.py): the rounding bit as the first cell's carry-in
    if s1:                                             # s1: both +s go to the table add as carry-in s at position 1;
        lits, R = lits[1:], list(R[1:])                # this add starts at position 1 (the guard untouched)
    if s1 and isinstance(_MUXSPLIT.get("opt"), dict) and _MUXSPLIT["opt"].get("lo2"):
        def mk0():                                     # R48-INV-S7C "lo2": f + 2 (NOT f) Tl_0 = Tl_0 + (Tl_0 xor f):
            c.cx(T[0], f)                              # f's wire holds Tl_0 xor f during the first cell only
            return T[0]

        def rl0():
            c.cx(T[0], f)
        lits = [(mk0, rl0), plain(None)] + lits[2:]
        cin = f
    bid = len(c.blocks)
    c.blocks[bid] = None
    c.ops.append(("BBEG", bid))
    debts = _fwd_stream(c, NW, lits, R, NW._lit(cin))
    c.ops.append(("BEND", bid))
    assert not hold
    save = c.ops
    c.ops = []
    import invsqrt_fc_s8m3 as _M3z                     # FC8 c0m (mux)
    _phm = _M3z.ph_free(c).__enter__() if _M3z.PH else None
    _R_mr = R
    R = _M3z.ph_target(R)
    if _MUXSPLIT.get("opt"):                           # F3 (twelfth holder) "muxopt": the undo by invsqrt_fw_m7mux
        import invsqrt_fw_m7mux as MX                  # (rotated / held / transient mux bits, game at spec C)
        cost = MX.mux_undo(c, NW, T, f, R, w0, s1, debts, _MUXSPLIT["opt"] if isinstance(_MUXSPLIT["opt"], dict)
                           else None, cin=cin_w)               # I39-SLOT10 (inv_i39_patch_slot10.py)
        C = -1
        if _phm is not None:                           # FC8 c0m mux end (opt)
            _phm.__exit__()
        R = _R_mr
        c.blocks[bid] = _M3z.ph_fix(c.ops)
        c.ops = save
        F8.__dict__.setdefault("_fc2_mux_log", []).append((C, cost))
        return
    Z2, Z3 = c.alloc(2)
    c.x(f)
    c.and_compute(f, T[0], Z2)
    c.x(f)
    c.cx(T[0], T[1])
    c.and_compute(f, T[1], Z3)                         # f (Tl_0 xor Tl_1)
    c.cx(T[0], T[1])
    c.cx(T[1], Z3)                                     # Z3 = Tl_1 xor f (Tl_0 xor Tl_1)
    # F3 (twelfth holder) "muxsplit" [q, ...]: positions q (5..10) read a temporary Zq = f ? Tl_(q-3) : Tl_(q-2)
    # (one AND each) and the rotation runs as shorter chains between them (one CSWAP less each way per split)
    splits = sorted(int(q) for q in (_MUXSPLIT.get("q") or []))
    Zq = {}
    for q in splits:
        assert 5 <= q <= 10, q
        z_ = c.alloc(1)[0]
        c.cx(T[q - 3], T[q - 2])
        c.and_compute(f, T[q - 2], z_)
        c.cx(T[q - 3], T[q - 2])
        c.cx(T[q - 2], z_)
        Zq[q] = z_
    bounds = [1] + [q - 2 for q in splits] + [9]       # chain wire ranges [a, b): T[a..b-1] rotated up under f
    chain = []
    for a_r, b_r in zip(bounds[:-1], bounds[1:]):
        chain += [(T[k], T[k + 1]) for k in range(b_r - 2, a_r - 1, -1)]
    for a_, b_ in chain:
        c.cswap(f, a_, b_)
    srcu = [w0, f, Z2, Z3] + [Zq[k + 2] if (k + 2) in Zq else T[k] for k in range(2, 9)]
    if s1:
        srcu = srcu[1:]
    n = len(R)
    C = c.cap - c.live
    for w in R:
        c.x(w)
    if NW.plan(max(0, n - 2 - NW.free_prefix(srcu, n, cin)), C)[0] is not None:
        cost = NW.game_add(c, srcu, R, cin, debts, C)
    elif C > NW.cuccaro_need(srcu, R, cin):
        cost = float(NW.hybrid_add(c, srcu, R, cin, debts, C))
    else:
        cost = float(NW.cuccaro_add(c, srcu, R, cin, debts))
    for w in R:
        c.x(w)
    for a_, b_ in reversed(chain):
        c.cswap(f, a_, b_)
    for q in reversed(splits):
        z_ = Zq[q]
        c.cx(T[q - 2], z_)
        c.cx(T[q - 3], T[q - 2])
        c.and_erase(f, T[q - 2], z_, free=False)
        c.cx(T[q - 3], T[q - 2])
        c.free_([z_])
    c.cx(T[1], Z3)
    c.cx(T[0], T[1])
    c.and_erase(f, T[1], Z3, free=False)
    c.cx(T[0], T[1])
    c.x(f)
    c.and_erase(f, T[0], Z2, free=False)
    c.x(f)
    c.free_([Z3, Z2])
    if _phm is not None:                               # FC8 c0m mux end
        _phm.__exit__()
    R = _R_mr
    c.blocks[bid] = _M3z.ph_fix(c.ops)
    c.ops = save
    F8.__dict__.setdefault("_fc2_mux_log", []).append((C, cost))


# ---- R43-INV-S7 (designer): the short-word table (cfg h1c "sw"); off = FC2's file
class _Net:
    """a tiny symbolic layer for hand programs in F1's format: a signal = a frozenset of indices (inputs, gates)
    meaning their XOR; AND(a, b) adds one gate whose two factors each own an index the other lacks (what F3's
    emitters need) and returns the product as a signal."""

    def __init__(self, nin):
        self.n, self.gates = nin, []

    def AND(self, a, b):
        a, b = frozenset(a), frozenset(b)
        if a == b:
            return a
        extra = frozenset()
        if not (a - b):                                # a inside b: a b = a (a ^ b) ^ a
            b, extra = a ^ b, a
        elif not (b - a):                              # b inside a: a b = (a ^ b) b ^ b
            a, extra = a ^ b, b
        self.gates.append({"left": sorted(a), "right": sorted(b)})
        return frozenset([self.n + len(self.gates) - 1]) ^ extra

    def OR(self, a, b):
        return frozenset(a) ^ frozenset(b) ^ self.AND(a, b)

    def MAJ(self, a, b, c):
        a, b, c = frozenset(a), frozenset(b), frozenset(c)
        return self.AND(a ^ c, b ^ c) ^ c


def sp_hand(fold=("x45",)):
    """S' = M6 + M5 + folded literals by hand: 6 ORs + a ripple of the two words (5 ANDs); inputs x0..x5 = Tf2..Tf7;
    outputs = bits 0..5. fold: names among t7, x45, x25 (at most two)."""
    N = _Net(6)
    X = lambda *ks: frozenset(k - 2 for k in ks)       # folded bit indices -> input indices
    e6, e5 = X(6, 7), X(5, 6)
    m = [e6] + [N.OR(e6, X(i, 6)) for i in (2, 3, 4, 5)]
    n_ = [e5] + [N.OR(e5, X(i, 5)) for i in (3, 4)]
    lit = {"t7": X(7), "x45": X(4, 5), "x25": X(2, 5)}
    ext = [lit[f] for f in fold]
    outs = []
    # position 0: m0 + n0 + ext[0] (+ ext[1] as a second carry chain entry at position 0 of the next cell)
    cols = [[m[0], n_[0]] + ext, [m[1], n_[1]], [m[2], n_[2]], [m[3]], [m[4]], []]
    for p in range(6):
        col = cols[p]
        while len(col) > 2:                            # full adders
            a, b, c_ = col[:3]
            col = col[3:] + [a ^ b ^ c_]
            cols[p + 1].append(N.MAJ(a, b, c_))
        if len(col) == 2:
            a, b = col
            col = [a ^ b]
            if p < 5:
                cols[p + 1].append(N.AND(a, b))
        outs.append(sorted(col[0]) if col else [])
    return {"gates": N.gates, "outputs": outs}


def v1_hand():
    """V' = (M6 + M5 + x45 + x25 + 1 - g) >> 1 by hand (14 ANDs): inputs x0..x5 = Tf2..Tf7, x6 = g; outputs = the 5
    bits of V' (units). V' = A6 + A5 + c1 + c2 with A6 = e6 ? 15 : X6, A5 = e5 ? 3 : X5 and c1 + c2 = the carry of the
    half-unit column e6 + e5 + x45 + x25 + (1 - g)."""
    N = _Net(7)
    X = lambda *ks: frozenset(k - 2 for k in ks)
    g = frozenset([6])
    e6, e5 = X(6, 7), X(5, 6)
    o = [N.OR(e6, X(i, 6)) for i in (2, 3, 4, 5)]
    n_ = [N.OR(e5, X(i, 5)) for i in (3, 4)]
    x45, x25 = X(4, 5), X(2, 5)
    c1 = N.MAJ(e6, e5, x45)
    s1 = e6 ^ e5 ^ x45
    c2 = N.AND(s1 ^ g, x25 ^ g) ^ s1 ^ x25 ^ g        # MAJ(s1, x25, NOT g)
    cols = [[o[0], n_[0], c1, c2], [o[1], n_[1]], [o[2]], [o[3]], [], []]
    outs = []
    for p in range(5):
        col = cols[p]
        while len(col) > 2:
            a, b, c_ = col[:3]
            col = col[3:] + [a ^ b ^ c_]
            cols[p + 1].append(N.MAJ(a, b, c_))
        if len(col) == 2:
            a, b = col
            col = [a ^ b]
            cols[p + 1].append(N.AND(a, b))
        outs.append(sorted(col[0]) if col else [])
    return {"gates": N.gates, "outputs": outs}


def prog_eval(prog, nin, vec=None):
    """the program's output values on all 2^nin input rows (row bit i = input i); with vec: the value on that one
    input vector."""
    out = []
    for r in ([0] if vec is not None else range(1 << nin)):
        v = list(vec) if vec is not None else [(r >> i) & 1 for i in range(nin)]
        for g in prog["gates"]:
            a = 0
            for x in g["left"]:
                a ^= v[x]
            b = 0
            for x in g["right"]:
                b ^= v[x]
            v.append(a & b)
        val = 0
        for k, lst in enumerate(prog["outputs"]):
            bit = 0
            for x in lst:
                bit ^= 1 if x == -1 else v[x]
            val |= bit << k
        out.append(val)
    return out[0] if vec is not None else out


def lin_bit0(vals, nin):
    """bit 0 of the table as an XOR of inputs (asserts it is linear without a constant)."""
    a = [v & 1 for v in vals]
    for b in range(nin):
        for z in range(1 << nin):
            if z >> b & 1:
                a[z] ^= a[z ^ (1 << b)]
    idx = []
    for z in range(1 << nin):
        if a[z]:
            assert bin(z).count("1") == 1, ("bit 0 of the table is not linear", z)
            idx.append(z.bit_length() - 1)
    return idx


def _cone(prog, n, o):
    """R45-INV-S7B: the single-output program of output o of a joint program (its gates only, re-indexed)."""
    need, stack = set(), [x - n for x in prog["outputs"][o] if x >= n]
    while stack:
        j = stack.pop()
        if j in need:
            continue
        need.add(j)
        stack += [x - n for x in prog["gates"][j]["left"] + prog["gates"][j]["right"] if x >= n]
    order = sorted(need)
    idx = {j: i for i, j in enumerate(order)}
    mp = lambda x: x if x < n else n + idx[x - n]
    return {"gates": [{"left": [mp(x) for x in prog["gates"][j]["left"]],
                       "right": [mp(x) for x in prog["gates"][j]["right"]]} for j in order],
            "outputs": [[mp(x) for x in prog["outputs"][o]]]}


def _take(c, ws):
    """R45-INV-S7B: take back lent wires (free and zero again) whatever the order of the kit's free list."""
    for w_ in ws:
        c.free.remove(w_)
        c.live += 1
    c.peak = max(c.peak, c.live)
    if c.tags:
        c.stage_peaks[c.tags[-1][1]] = max(c.stage_peaks.get(c.tags[-1][1], 0), c.live)


def _r62_unadd(c, NW, src, tgt, cin, debts, m0, Cc, force):   # R62-P2 (r62_inv_word_p2.py)
    """tgt += src + cin (the caller sets the X frame): word wires on the low positions, zero sources above, the top
    is c0's phantom. force (or no clean wire): Cuccaro MAJ / UMA in the word wires and ONE ladder wire."""
    n = len(tgt)
    src = list(src) + [None] * (n - len(src))
    debts = debts or {}
    L = max(i for i, a in enumerate(src) if NW._w(a)) + 1
    ok = (all(NW._w(a) for a in src[:L]) and all(a is None for a in src[L:]) and n - 1 - L == 3 and NW._w(cin)
          and m0 is not None)
    if not (force and ok):
        if NW.plan(max(0, n - 2 - NW.free_prefix(src, n, cin)), Cc)[0] is not None:
            NW.game_add(c, src, tgt, cin, debts, Cc)
            return "game"
        if Cc >= 2:                                    # F3's mixed form, as the stage uses for the word today
            import invsqrt_fw_c1add as CA
            if CA.NW is None:
                CA.NW = NW
            CA.mixed_add(c, src, tgt, cin, debts, Cc, L - 1, int(os.environ.get("C1CCZ", "1")))
            return "mixed"
        if Cc > NW.cuccaro_need(src, tgt, cin):
            NW.hybrid_add(c, src, tgt, cin, debts, Cc)
            return "hybrid"
        if not ok:
            NW.cuccaro_add(c, src, tgt, cin, debts)
            return "cuccaro"
    import invsqrt_fw_fcgen as _G
    _G._install_ops()
    chain = [cin] + src[:L]
    for i in range(L):                                 # MAJ: src[i] -> c_(i+1), debts repaid there
        x, y, z = chain[i], tgt[i], src[i]
        c.cx(z, y)
        c.cx(z, x)
        c.ccx(x, y, z)
        if (i + 1) in debts:
            c.z(z, debts[i + 1])
    k = src[L - 1]                                     # c_L
    t0, t1, t2 = tgt[L], tgt[L + 1], tgt[L + 2]
    A = c.alloc(1)[0]
    c.and_compute(k, t0, A)                            # c_(L+1) = c_L t0
    if (L + 1) in debts:
        c.z(A, debts[L + 1])
    if (L + 2) in debts:
        c.cz(A, t1, debts[L + 2])                      # c_(L+2) = A t1: its debt is a conditioned CZ
    c.xccz(A, t1, t2, m0)                              # the phantom top ^= c_(L+3) = A t1 t2: a CCZ under m0
    c.ccx(A, t1, t2)                                   # t2 ^= c_(L+2)
    c.cx(A, t1)                                        # t1 ^= c_(L+1)
    c.and_erase(k, t0, A)
    c.cx(k, t0)                                        # t0 ^= c_L
    for i in range(L - 1, -1, -1):                     # UMA
        x, y, z = chain[i], tgt[i], src[i]
        c.ccx(x, y, z)
        c.cx(z, x)
        c.cx(x, y)
    return "r62-ladder1"


def _sword_g0(F8, c, o, T, R, s, nb, lits, tog, tstate, par, first=False):
    """THE GUARD OUT OF THE WORD ("sw": {"g0": 1}): this word is the stage's last one with half-unit content. The
    guard's bit g at this moment is the XOR of the frame's `par` (T wires, s, a constant): the guard is cleared by
    CNOTs and FREED, g is formed on a T wire and given to the table as its last input, and the table holds the word in
    UNITS, V' = (V + 1 - g) >> 1 with V = M6 + M5 + the folded borrow-in literals (every remaining one): the pass runs
    on R[1..] with no carry-in. The half-unit bit itself is never materialised (FC2's stage discards it anyway)."""
    import invsqrt_fc_narrow as NW
    from invsqrt_fc2_patch_h1b import _fwd_stream
    import invsqrt_fw_chiprog as CP
    sw = o["sw"]
    lo = int(sw.get("lo", 2))
    vals = [int(v) for v in sw["vals"]]
    nin = int(sw.get("nin", 6 if first else 7))        # first: the word runs BEFORE the guard exists (g = 0): the
    assert len(vals) == 1 << nin                       # table is (V + 1) >> 1 of Tf2..Tf7 alone; R[0] is not there yet
    stages = sw.get("stages")                          # [[bit, given bits, single-output program], ...] (F3's form)
    _ust8 = sw.get("ustages")                          # FC8: the undo's own stages (same form), checked below
    if _ust8:
        for r_ in range(1 << nin):
            for b_, given, pg in _ust8:
                v_ = [(r_ >> i) & 1 for i in range(nin)] + [(vals[r_] >> d) & 1 for d in given]
                bs_ = b_ if isinstance(b_, list) else [b_]
                assert prog_eval({"gates": pg["gates"], "outputs": pg["outputs"]}, 0, v_) == sum(
                    ((vals[r_] >> q_) & 1) << i_ for i_, q_ in enumerate(bs_)), "ustages: not the table"
    if stages:
        nbit = sum(len(b_) if isinstance(b_, list) else 1 for b_, _g, _p in stages)
        for r_ in range(1 << nin):                     # the stages are the table
            for b_, given, pg in stages:
                v_ = [(r_ >> i) & 1 for i in range(nin)] + [(vals[r_] >> d) & 1 for d in given]
                bs_ = b_ if isinstance(b_, list) else [b_]
                assert prog_eval({"gates": pg["gates"], "outputs": pg["outputs"]}, 0, v_) == sum(
                    ((vals[r_] >> q_) & 1) << i_ for i_, q_ in enumerate(bs_))
    else:
        pa = sw["prog"] if isinstance(sw["prog"], dict) else json.load(open(os.path.expanduser(sw["prog"])))
        assert prog_eval(pa, nin) == vals, "sw g0: the program is not the table"
        prog = {"gates": pa["gates"], "outputs": pa["outputs"]}
        nbit = len(prog["outputs"])
    s_out = bool(sw.get("s_out") or sw.get("sconj") or sw.get("cubin"))   # the -64 s is NOT in this word
    assert bool(o.get("cubfold")) and bool(o.get("cubtab")) and nbit <= (6 if s_out else 5) and not o.get("cub")

    def table(bw_, st8=None, skip0=False):                 # R62-P2 (r62_inv_word_p2.py)
        if not stages:
            return CP.emit_cub_auto_prog(c, zin, bw_, prog)
        k_ = 0
        done_ = [0] if skip0 else []
        for b_, given, pg in (st8 or stages):
            bs_ = b_ if isinstance(b_, list) else [b_]
            lend_ = isinstance(b_, list) or bool(sw.get("lend"))   # R45-INV-S7B: the wires of the bits not
            pend_ = [w_ for i_, w_ in enumerate(bw_) if i_ not in done_ and i_ not in bs_] if lend_ else []
            c.free_(pend_)                             # made yet are lent to this stage (temporaries)
            _ins8 = list(zin) + [bw_[d] for d in given]          # FC8 acc: F3's accumulator emission when
            _out8 = [bw_[q_] for q_ in bs_]                      # it is cheaper (outputs zero here)
            _bud8 = max(1, c.cap - c.live)
            if os.environ.get("FC8DBG"):
                print("FC8DBG table stage %s given %s budget %d lent %d" % (bs_, given, _bud8, len(pend_)))
            _done8 = False
            if sw.get("span"):                                   # FC8 span: XOR-combination storage (my
                _sp8 = CP.schedule(pg, len(_ins8), _bud8)       # emitter) where the plain schedule would
                if _sp8 is not None and _sp8[0] == len(pg["gates"]):   # recompute; plain kept when exact
                    k_ += CP.emit(c, pg, _ins8, _out8, _bud8, _sp8)
                    _done8 = True
                else:
                    import invsqrt_fc_s8spanemit as _SE8
                    _k8 = _SE8.emit_span(c, pg, _ins8, _out8, _bud8)
                    if _k8 is not None:
                        k_ += _k8
                        _done8 = True
                    if os.environ.get("FC8DBG"):
                        print("FC8DBG span emission of stage %s: %s" % (bs_, _k8))
            if _done8:
                pass
            elif sw.get("acc"):
                _sp8 = CP.schedule(pg, len(_ins8), _bud8)
                _sa8 = CP._acc_sched(pg, len(_ins8), _bud8, int(sw.get("acccap", 16)))
                if _sa8 is not None and (_sp8 is None or _sa8[0] < _sp8[0]):
                    k_ += CP.emit_acc(c, pg, _ins8, _out8, _bud8, _sa8)
                else:
                    k_ += CP.emit(c, pg, _ins8, _out8, _bud8, _sp8)
            else:
                k_ += CP.emit(c, pg, list(zin) + [bw_[d] for d in given], [bw_[q_] for q_ in bs_],
                              max(1, c.cap - c.live))
            _take(c, pend_)
            done_ += bs_
        return k_
    par0 = frozenset([6, 7]) ^ frozenset([5, 6])       # the half-unit bit of V: e6 ^ e5 ^ the folded literals
    if sw.get("row7"):                                 # (+ x17, row 7 part 2's half-unit literal)
        par0 = par0 ^ frozenset([1, 7])
    for f_ in sw.get("fold", []):
        lits.remove(frozenset(int(q) for q in f_))
        par0 = par0 ^ frozenset(int(q) for q in f_)
    assert first or not lits, ("sw g0: borrow-in literals outside the table", lits)
    Gd = R[0]
    assert (Gd is None) == bool(first), "sw: 'first' needs gdlate (no guard yet); g0 needs the guard"
    names = sorted(par) if not first else []

    def lin(target, skip=None):
        ops = []
        for v_ in names:
            if v_ == "one":
                ops.append(("x", target))
            elif v_ == "s":
                ops.append(("cx", s, target))
            elif T[int(v_[2:])] != skip:
                ops.append(("cx", T[int(v_[2:])], target))
        return ops
    zt = [T[lo + i] for i in range((nin - (1 if sw.get("sin") else 0)) if first else nin - 1)]
    if sw.get("sin"):                                  # R45-INV-S7B: the sign wire as the table's last input
        zt = zt + [s]
    pre, car = [], None
    if not first:
        for op in lin(Gd):                             # the guard holds XOR(par): clear it, free the wire
            _do(c, op)
        c.free_([Gd])
        cand = [T[int(v_[2:])] for v_ in names if v_.startswith("Tf") and T[int(v_[2:])] not in zt]
        assert cand, "sw g0: no carrier for the guard's bit"
        car = cand[0]
        pre = lin(car, skip=car)                       # car = g
        for op in pre:
            _do(c, op)
    zin = zt + ([car] if not first else [])
    Rt = list(R[1:])
    nt = len(Rt)
    import invsqrt_fc_s8m3 as _M3x                     # FC8 c0m (word)
    for t in _M3x.ph_real(Rt):
        c.x(t)
    bid = len(c.blocks)
    c.blocks[bid] = None
    c.ops.append(("BBEG", bid))
    _r62w0 = (bool((o.get("r62") or {}).get("w0slot")) and bool(first) and bool(F8.__dict__.get("_i39_lend"))
              and bool(stages) and s_out)             # R62-P2 (r62_inv_word_p2.py)
    if _r62w0:
        assert Rt[0] == F8.__dict__["_i39_lend"][0], "w0slot: the slot is the pass's lowest target"
        c.x(Rt[0])                                     # the framed slot (1) -> 0: the word's bit 0 lives here
        bw = [Rt[0]] + c.alloc(nbit - 1)
    else:
        bw = c.alloc(nbit)
    _lend = [w_ for w_ in list(F8.__dict__.get("_i39_lend") or []) if not (_r62w0 and w_ == Rt[0])]   # I39-SLOT2 (inv_i39_patch_slot2.py): slot and c0 lent while they are zero
    _lx = [w_ for w_ in _lend if w_ in _M3x.ph_real(Rt)]   # I39-SLOT3 (inv_i39_patch_slot3.py): framed (X) lent wires hold 1: X them to 0
    for w_ in _lx:
        c.x(w_)
    if _lend:
        c.free_(_lend)
    k_f = table(bw)
    if _lend:
        _take(c, _lend)
    for w_ in _lx:
        c.x(w_)
    if s_out:
        srcw = list(bw) + [None] * (nt - nbit)
    else:
        srcw = list(bw) + [None] * (5 - nbit) + [s] + [None] * (nt - 6)
    if os.environ.get("FC2DBG"):
        print("DBG sword g0: program %s ANDs fwd, live %d cap %d, par %s, carrier %s, first %s" % (
            k_f, c.live, c.cap, names, None if car is None else T.index(car), bool(first)))
    _strm = bool(F8.__dict__.get("_i39_stream")) and (not sw.get("hold") or F8.__dict__.get("_i39_rowsfirst"))   # I39-SLOT5 (inv_i39_patch_slot5.py): table bits measured as read
    _mb = {}

    def _rel(w_):
        if _strm and w_ in bw and w_ not in _mb:
            _mb[w_] = c.hmr(w_)
            c.free_([w_])
    lits_ = [((lambda w_=w_: w_), (lambda w_=w_: _rel(w_))) for w_ in srcw]
    _cw = s if sw.get("cinsb") else None
    _cp = [T[int(q_)] for q_ in sw.get("cinp", [])]    # "cinp": the FLOOR table (S >> 1) with the carry-in p = the
    assert not (_cp and _cw is not None)               # half-unit bit of S, formed on its first T wire by CNOTs

    def _cin(on):
        if _cp:
            for w_ in _cp[1:]:
                c.cx(w_, _cp[0])
        elif _cw is not None:
            c.x(s)
    if _cp:
        _cw = _cp[0]
    elif _cw is not None:
        assert sw.get("sconj")
    _cin(True)
    if _r62w0:                                         # R62-P2 (r62_inv_word_p2.py)
        assert _cw is not None and sw.get("hold"), "w0slot: needs a carry-in wire and the held carry"
        import invsqrt_fc_s8m3 as _M3h
        _c1 = c.alloc(1)[0]
        c.x(Rt[0])
        c.x(_cw)
        c.and_compute(Rt[0], _cw, _c1)                 # NOT (w0 OR p)
        c.x(Rt[0])
        c.x(_cw)
        c.x(_c1)                                       # c1 = w0 OR p: the framed target bit is 1
        c.cx(_cw, Rt[0])
        c.x(Rt[0])                                     # the framed sum bit 1 ^ w0 ^ p
        debts = _M3h.word_hold(c, NW, _fwd_stream, lits_[1:], Rt[1:], _c1, srcw[1:], bid)
        _M3h.HOLD["rpos"] += 1
        _M3h.HOLD["bits"] = {k_ + 1: v_ for k_, v_ in _M3h.HOLD["bits"].items()}
        c.x(Rt[0])
        c.cx(_cw, Rt[0])                               # the slot is w0 again: c1 erased by measurement
        c.x(_c1)
        c.x(Rt[0])
        c.x(_cw)
        c.and_erase(Rt[0], _cw, _c1)
        c.x(Rt[0])
        c.x(_cw)
        c.cx(_cw, Rt[0])
        c.x(Rt[0])
    elif sw.get("hold"):                              # FC8: the word's carry held for the rows' pass
        import invsqrt_fc_s8m3 as _M3h
        debts = _M3h.word_hold(c, NW, _fwd_stream, lits_, Rt, _cw, srcw, bid)
    else:
        debts = _fwd_stream(c, NW, lits_, Rt, NW._lit(_cw))
    _cin(False)
    mbits = [None if (_r62w0 and w == bw[0]) else (_mb[w] if w in _mb else c.hmr(w)) for w in bw]   # I39-SLOT5 (inv_i39_patch_slot5.py)
    c.free_([w for w in bw if w not in _mb and not (_r62w0 and w == bw[0])])   # R62-P2 (r62_inv_word_p2.py)
    c.ops.append(("BEND", bid))
    save = c.ops
    c.ops = []
    _phu = _M3x.ph_free(c).__enter__() if _M3x.PH else None   # FC8 c0m U
    _Rt_real = Rt
    Rt = _M3x.ph_target(Rt)
    if _r62w0:                                         # R62-P2 (r62_inv_word_p2.py)
        if _mb:
            _take(c, list(bw[1:]))
        else:                                          # a build without the streamed release
            bw2 = c.alloc(nbit - 1)
            assert list(bw2) == list(bw[1:]), ("table wires", bw2, bw)
        assert len(stages) == 1 and list(stages[0][0]) == list(range(nbit)) and not stages[0][1]
        _pg6 = stages[0][2]
        k_u = table(bw, [[list(range(1, nbit)), [], {"gates": _pg6["gates"], "outputs": _pg6["outputs"][1:]}]],
                    skip0=True)
        for w, mb in zip(bw[1:], mbits[1:]):
            c.z(w, mb)
        _cin(True)
        c.x(Rt[0])
        c.cx(_cw, Rt[0])                               # the framed slot 1 ^ w0 ^ p -> w0 on its wire
        _c1 = c.alloc(1)[0]
        c.x(Rt[0])
        c.x(_cw)
        c.and_compute(Rt[0], _cw, _c1)
        c.x(Rt[0])
        c.x(_cw)
        c.x(_c1)                                       # c1 = w0 OR p (erased clean in the forward: no debt)
        Cc = c.cap - c.live
        for w in Rt[1:]:
            c.x(w)
        how = _r62_unadd(c, NW, srcw[1:], Rt[1:], _c1, debts, (_M3x.PH or {}).get("m0"), Cc,
                         bool((o.get("r62") or {}).get("unadd1")))
        for w in Rt[1:]:
            c.x(w)
        c.x(_c1)
        c.x(Rt[0])
        c.x(_cw)
        c.and_erase(Rt[0], _cw, _c1)
        c.x(Rt[0])
        c.x(_cw)                                       # the slot holds w0: bit 0's measured clear takes it
        _cin(False)
    if _r62w0:
        pass
    elif _mb:                                          # I39-SLOT5 (inv_i39_patch_slot5.py): the same wires back
        _take(c, list(bw))
    else:
        bw2 = c.alloc(nbit)
        assert list(bw2) == list(bw), ("table wires", bw2, bw)
    if not _r62w0:
        k_u = table(bw, _ust8)
        for w, mb in zip(bw, mbits):
            c.z(w, mb)
        Cc = c.cap - c.live
        for w in Rt:
            c.x(w)
        _cin(True)
    if _r62w0:
        pass
    elif NW.plan(max(0, nt - 2 - NW.free_prefix(srcw, nt, _cw)), Cc)[0] is not None and not sw.get("mixed") == 2:
        NW.game_add(c, srcw, Rt, _cw, debts, Cc)
        how = "game"
    elif sw.get("mixed") and Cc >= 2:                  # R45-INV-S7B: F3's mixed form (as the cubic's un-add)
        import invsqrt_fw_c1add as CA
        if CA.NW is None:
            CA.NW = NW
        CA.mixed_add(c, srcw, Rt, _cw, debts, Cc, nbit - 1, int(os.environ.get("C1CCZ", "1")))
        how = "mixed"
    elif Cc > NW.cuccaro_need(srcw, Rt, _cw):
        NW.hybrid_add(c, srcw, Rt, _cw, debts, Cc)
        how = "hybrid"
    else:
        NW.cuccaro_add(c, srcw, Rt, _cw, debts)
        how = "cuccaro"
    if not _r62w0:                                     # R62-P2 (r62_inv_word_p2.py)
        _cin(False)
        for w in Rt:
            c.x(w)
    if stages:                                         # staged measured clear: the last-computed bit first, its
        k_c = 0.0                                      # phase repaid by its own stage program if the outcome is 1
        _fr = set()
        _clr = sw.get("clear")                         # R45-INV-S7B: the clear with its own order and one-bit
        _gone = set()                                  # programs (any program on the inputs and the bits still
        for b_, given, pg in (_clr or []):             # live; a quadratic one is conditioned CZ / Z only: free)
            assert b_ not in _gone and not (_gone & set(given)) and b_ not in given
            for r_ in range(1 << nin):
                v_ = [(r_ >> i) & 1 for i in range(nin)] + [(vals[r_] >> d) & 1 for d in given]
                assert prog_eval({"gates": pg["gates"], "outputs": pg["outputs"]}, 0, v_) == (vals[r_] >> b_) & 1
            g_ = c.hmr(bw[b_])
            _gone.add(b_)
            if _r62w0 and b_ == 0:                     # R62-P2 (r62_inv_word_p2.py)
                c.x(bw[0])                             # the slot back to its framed zero
                _fr.add(bw[0])
            elif sw.get("clrfree"):
                c.free_([bw[b_]])
                _fr.add(bw[b_])
            k_c += 0.5 * emit_phase_cond(c, pg, list(zin) + [bw[d] for d in given], g_)
        assert not _clr or len(_gone) == nbit
        for b_, given, pg in ([] if _clr else reversed(stages)):
            if isinstance(b_, list):                   # R45-INV-S7B block stage: every bit of the block is
                gs_ = [c.hmr(bw[q_]) for q_ in b_]     # measured, the wires are lent, each bit pays its phase
                ws_ = [bw[q_] for q_ in b_]            # by the cone of its own output
                c.free_(ws_)
                for i_, g_ in enumerate(gs_):
                    k_c += 0.5 * emit_phase_cond(c, _cone(pg, len(zin) + len(given), i_),
                                                 list(zin) + [bw[d] for d in given], g_)
                _take(c, ws_)
                continue
            g_ = c.hmr(bw[b_])
            k_c += 0.5 * emit_phase_cond(c, pg, list(zin) + [bw[d] for d in given], g_)
    else:
        k_c = CP.emit_cub_auto_prog(c, zin, bw, prog, uncompute=True)
    c.free_([w_ for w_ in bw if not (stages and w_ in _fr)])
    if os.environ.get("FC2DBG"):
        print("DBG sword g0 undo: Cc %d un-add %s, program %s, clear %s" % (Cc, how, k_u, k_c))
    if _phu is not None:                               # FC8 c0m U end
        _phu.__exit__()
    Rt = _Rt_real
    c.blocks[bid] = _M3x.ph_fix(c.ops)
    c.ops = save
    for t in _M3x.ph_real(Rt):
        c.x(t)
    if first:
        return sorted(par0)                            # the guard, when it is made, starts as the XOR of these Tf
    for op in reversed(pre):
        _do(c, op)
    g2 = c.alloc(1)[0]
    assert g2 == Gd, ("the guard's wire", g2, Gd)
    par.clear()                                        # the guard is zero from here on (nothing left to clear)


def _sword(F8, c, o, T, R, s, nb, lits, tog, tstate, par=None):
    """merged rows 6 and 5 (+ folded borrow-in literals) as ONE table word, subtracted from R in one pass."""
    if (o["sw"] or {}).get("first"):
        return None                                    # done before the guard (the stage's first branch)
    if (o["sw"] or {}).get("g0"):
        return _sword_g0(F8, c, o, T, R, s, nb, lits, tog, tstate, par)
    import invsqrt_fc_narrow as NW
    from invsqrt_fc2_patch_h1b import _fwd_stream
    import invsqrt_fw_chiprog as CP
    sw = o["sw"]
    pa = sw["prog"] if isinstance(sw["prog"], dict) else json.load(open(os.path.expanduser(sw["prog"])))
    lo, nin = int(sw.get("lo", 2)), int(sw.get("nin", 6))
    vals = [int(v) for v in sw["vals"]]
    assert prog_eval(pa, nin) == vals, "sw: the program is not the table"
    lin0 = lin_bit0(vals, nin)
    assert sorted(pa["outputs"][0]) == sorted(lin0), ("sw: bit 0", pa["outputs"][0], lin0)
    prog = {"gates": pa["gates"], "outputs": pa["outputs"][1:]}
    nbit = len(prog["outputs"])
    zin = [T[lo + i] for i in range(nin)]
    nR = len(R)
    spos = 1 + nbit                                    # the table's sign term -64 s (cubfold + cubtab) sits above
    assert bool(o.get("cubfold")) and bool(o.get("cubtab")) and spos <= 6
    for f_ in sw.get("fold", []):                      # literals inside the table leave the stage's list
        lits.remove(frozenset(int(q) for q in f_))
        tog(*["Tf%d" % int(q) for q in f_])
    tog("Tf6", "Tf7")                                  # e6 and e5: the position-0 content of the two merged rows
    tog("Tf5", "Tf6")
    for t in R:                                        # a subtraction = X^n . add . X^n
        c.x(t)
    bid = len(c.blocks)
    c.blocks[bid] = None
    c.ops.append(("BBEG", bid))
    bw = c.alloc(nbit)
    k_f = CP.emit_cub_auto_prog(c, zin, bw, prog)
    car0 = zin[lin0[0]]
    pre0 = [("cx", zin[q], car0) for q in lin0[1:]]
    st = tstate()
    st[car0] = (frozenset(lo + q for q in lin0), 0)
    cin, prec, got = None, [], None
    for L_ in list(lits):
        f_ = form_literal(st, L_, {car0, s})
        if f_ is not None:
            prec, cin = f_
            got = L_
            break
    if got is not None:
        lits.remove(got)
        tog(*["Tf%d" % q for q in got])
    srcw = [car0] + list(bw) + [None] * (6 - spos) + [s] + [None] * (nR - 7)
    if os.environ.get("FC2DBG"):
        print("DBG sword: program %s ANDs fwd, live %d cap %d, cin %s, bit0 %s" % (k_f, c.live, c.cap, got, lin0))

    def frame(on):
        ops = pre0 + prec
        for op in (ops if on else reversed(ops)):
            _do(c, op)
    frame(True)
    lits_ = [((lambda w_=w_: w_), (lambda: None)) for w_ in srcw]
    debts = _fwd_stream(c, NW, lits_, R, NW._lit(cin))
    frame(False)
    mbits = [c.hmr(w) for w in bw]
    c.free_(bw)
    c.ops.append(("BEND", bid))
    save = c.ops
    c.ops = []
    bw2 = c.alloc(nbit)
    assert list(bw2) == list(bw), ("table wires", bw2, bw)
    CP.emit_cub_auto_prog(c, zin, bw, prog)
    for w, mb in zip(bw, mbits):
        c.z(w, mb)
    frame(True)
    Cc = c.cap - c.live
    for w in R:
        c.x(w)
    how = None
    if NW.plan(max(0, nR - 2 - NW.free_prefix(srcw, nR, cin)), Cc)[0] is not None:
        NW.game_add(c, srcw, R, cin, debts, Cc)
        how = "game"
    elif Cc >= 2 and cin is not None:
        import invsqrt_fw_c1add as CA
        if CA.NW is None:
            CA.NW = NW
        CA.mixed_add(c, srcw, R, cin, debts, Cc, nbit, int(os.environ.get("C1CCZ", "1")))
        how = "mixed"
    elif Cc > NW.cuccaro_need(srcw, R, cin):
        NW.hybrid_add(c, srcw, R, cin, debts, Cc)
        how = "hybrid"
    else:
        NW.cuccaro_add(c, srcw, R, cin, debts)
        how = "cuccaro"
    for w in R:
        c.x(w)
    frame(False)
    CP.emit_cub_auto_prog(c, zin, bw, prog, uncompute=True)
    c.free_(bw)
    if os.environ.get("FC2DBG"):
        print("DBG sword undo: Cc %d un-add %s" % (Cc, how))
    c.blocks[bid] = c.ops
    c.ops = save
    for t in R:
        c.x(t)


_I39_WPOS = {"X": (1,), "CX": (1, 2), "CCX": (1, 2, 3), "SWAP": (1, 2), "CSWAP": (1, 2, 3), "Z": (1,),
             "CZ": (1, 2), "CCZ": (1, 2, 3), "ZP": (1,), "HMR": (1,), "ANDC": (1, 2, 3), "ANDE": (1, 2, 3),
             "CANDC": (1, 2, 3), "CANDE": (1, 2, 3), "NEG": (), "BBEG": (), "BEND": (), "CBEG": (), "CEND": ()}


def _i39_remap(o, a, b):                               # I39-SLOT (inv_i39_patch_slot.py): wire a -> b in one op
    pos = _I39_WPOS.get(o[0])
    if pos is None:
        assert a not in o[1:], ("i39 remap: unknown op touching the wire", o)
        return o
    return tuple(b if (k in pos and v == a) else v for k, v in enumerate(o))


_I39_C = {"c": None}


def _i39_ph_fix(ops):                                  # I39-SLOT3 (inv_i39_patch_slot3.py): ph_fix + gated writes into the phantom
    import invsqrt_fc_s8m3 as M3_
    if not M3_.PH:
        return ops
    Pw, m0 = M3_.PH["P"], M3_.PH["m0"]
    c_ = _I39_C["c"]
    out, rest = [], []

    def dbit(g):
        d = c_.bit()
        if not hasattr(c_, "bprob"):
            c_.bprob = {}
        c_.bprob[d] = 0.5 * c_.bprob.get(g, 0.5)
        out.append(("BAND", d, ((m0, 1), (g, 1))))
        return d
    for o in ops:
        g = o[0]
        if g == "XCCX" and o[3] == Pw:
            assert Pw not in o[1:3]
            out.append(("CZ", o[1], o[2], dbit(o[4])))
        elif g == "CX" and o[2] == Pw and o[3] is not None:
            out.append(("Z", o[1], dbit(o[3])))
        elif g == "X" and o[1] == Pw and o[2] is not None:
            out.append(("NEG", dbit(o[2])))
        else:
            out.extend(M3_._i39_orig_ph_fix([o]))
    return out


def stage(F8, c, U, cfg):
    """U: 27 - m wires, y in two's complement (LSB first). Leaves U = y + h + off; returns c0 (held)."""
    A = F8.A
    o = opts(cfg)
    nb, nc = int(o["nb"]), int(o["nc"])
    merge = sorted(int(j) for j in o.get("merge", []))
    cubfold = bool(o.get("cubfold"))
    s1 = bool(o.get("s1")) and cubfold and bool(o.get("mux")) and bool(o.get("cubtab")) and bool(o.get("cubdebt"))
    assert len(U) == 9 + nb + 1, ("h1c: U has %d wires, nb %d" % (len(U), nb))
    assert nc in (1, 3)
    L, T = list(U[:9]), list(U[9:])
    s = T[nb]
    if o.get("slot") is not None or (o.get("r64") or {}).get("phfix"):   # I39-SLOT3 (inv_i39_patch_slot3.py): gated phantom writes -> phases; R64-P1 (r64_inv_stack_p1.py): also without a slot
        import invsqrt_fc_s8m3 as _M3i
        _I39_C["c"] = c
        if not hasattr(_M3i, "_i39_orig_ph_fix"):
            _M3i._i39_orig_ph_fix = _M3i.ph_fix
        _M3i.ph_fix = _i39_ph_fix
    gdlate = bool(o.get("gdlate")) and s1 and not o.get("gdinit")   # FC2 (fifth holder): the s1 mux add never
    if gdlate:                                         # touches position 0: the guard is allocated after it
        cw = c.alloc(nc)
        Gd = None
    else:
        Gd = c.alloc(1)[0]
        cw = c.alloc(nc)
    R = [Gd] + L + list(cw)
    nR = len(R)
    import invsqrt_fc_s8m3 as _M3c                     # FC8 c0m
    _M3c.PH.clear()
    if o.get("c0m"):
        _M3c.c0m_begin(c, cw[0])
    if o.get("c0free"):                              # FC8 COUNT ONLY: c0's wire given to the
        c.free_([cw[0]])                               # allocator through the stage (one more clean
        c.free.remove(cw[0])                           # wire for every undo; the circuit is WRONG)
        c.free.insert(0, cw[0])
    for i in range(nb):
        c.cx(s, T[i])                                  # T[i] = Tf_i
    par = set()                                        # XOR terms of R[0] (the guard): "Tf<i>", "s" or "one"

    def tog(*vs):
        for v_ in vs:
            par.symmetric_difference_update({v_})

    gi = o.get("gdinit")                               # the guard's start value: one free half unit times a literal
    if gi:                                             # "one", "t<k>" (Tf_k), "n<k>" (NOT Tf_k), "x<i>_<j>", "y<i>_<j>"
        if gi == "one":                                # (NOT x_ij); cleared with the parity at the stage's end
            c.x(Gd)
            tog("one")
        else:
            ks = [int(q) for q in gi[1:].split("_")]
            for k_ in ks:
                c.cx(T[k_], Gd)
                tog("Tf%d" % k_)
            if gi[0] in "ny":
                c.x(Gd)
                tog("one")

    kst = {"k": int(o["K2"]) + 2 * int(o["off"])}      # constant still to place (half units): carry-ins (+1 each on
                                                       # an addition) or borrow-ins (-1 each on a subtraction)

    _CHI["mode"] = o.get("chi", "fc2")
    _TABPROG["prog"] = (o["cubprog"] if o.get("cubprog") == "f3" else
                        json.load(open(os.path.expanduser(o["cubprog"]))) if o.get("cubprog") else None)
    lits = [frozenset([int(b)]) for b in o.get("cin_bits", [])]
    lits += [frozenset([int(a_), int(b_)]) for a_, b_ in o.get("cin_pairs", [])]

    def tstate(row=None, kind=None):
        """current folded-bit content of T[0..nb-1] (as a set) and its negation, during a row's subtraction."""
        st = {T[k]: (frozenset([k]), 0) for k in range(nb)}
        if row is not None:
            j, idx = row
            for i in idx:
                st[T[i]] = (frozenset([i, j]), 1 if kind == "merged" else 0)
            if kind == "merged":
                st[T[j + 1]] = (frozenset([j, j + 1]), 0)
        return st

    def addw(word, sign, cin=None, cvar=None, row=None, kind=None, snot=False):
        """R += word (sign +1) or R -= word (sign -1); word = {pos: wire or ONE} (positions >= nR drop: mod 2^nR);
        cin: a given carry-in wire (cvar its parity name), else (subtractions) a borrow-in literal of the stage
        (cin_bits / cin_pairs) formed by CNOTs on a T wire that is not a source, else one unit of the constant."""
        if isinstance(cin, tuple) and cin[0] == "x0":       # R48-INV-S7C: the row starts at position 1 with the
            import invsqrt_fc_s8m3 as _M3x                  # carry-in wire cin[1]; the guard is not touched
            assert sign < 0 and word.get(0) is None and kind == "plain" and _M3c.PH and o.get("m3")
            src1 = [word.get(p) for p in range(1, nR)]
            while src1 and src1[-1] is None:
                src1.pop()
            _Rx = _M3c.ph_real(R)
            for t in _Rx:
                c.x(t)
            nb0_ = len(c.blocks)
            aux_ = cin[2] if len(cin) > 2 else None
            if aux_ is not None:
                aw_ = c.alloc(1)[0]
                pre_, post_ = aux_(aw_)
                cw_ = aw_
            else:
                cw_ = cin[1]
            gl_ = bool(o.get("x0g")) and aux_ is not None and R[0] is not None
            if gl_:                                         # "x0g": this row never reads the guard: in its UNDO the
                import invsqrt_fw_m7gv as GVMx              # guard (an XOR of T's wires) is cleared by CNOTs and its
                st_ = {w_: (frozenset("Tf%d" % q for q in fs_), ng_)   # wire lent to the game (one more clean wire)
                       for w_, (fs_, ng_) in tstate(row, kind).items()}
                st_[T[nb]] = (frozenset(["s"]), 0)
                gws_, gng_ = GVMx.solve(st_, set(par))      # guard = XOR(gws_) xor gng_; inside the X frame: its NOT
                gops_ = [("CX", w_, R[0], None) for w_ in sorted(gws_)] + [("X", R[0], None)] * (1 ^ int(gng_))
                c.free_([R[0]])
                c.free.remove(R[0])
                c.free.insert(0, R[0])
            with _M3c.ph_free(c):
                A.add(c, src1, _M3c.ph_target(R)[1:], cin=cw_)
            assert len(c.blocks) == nb0_ + 1
            if gl_:
                assert R[0] in c.free, "x0g: the guard's wire is still held"
                c.free.remove(R[0])
                c.live += 1
                c.peak = max(c.peak, c.live)
            if aux_ is not None:
                _M3x.AUX[nb0_] = ((pre_, post_, aw_, gops_ + pre_, post_ + gops_[::-1]) if gl_ else
                                  (pre_, post_, aw_))
                c.free_([aw_])
            for t in _Rx:
                c.x(t)
            return
        src = [word.get(p) for p in range(nR)]
        while src and src[-1] is None:
            src.pop()
        pre = []
        cterms = set()
        if cin is not None:
            tog(cvar)
            cterms = {cvar}
        elif sign < 0 and lits and kst["k"] == 0:
            st = tstate(row, kind)
            for L_ in (list(reversed(lits)) if o.get("m3rev") else list(lits)):   # FC8: m3rev lits
                f_ = form_literal(st, L_, set(w for w in src if isinstance(w, int)))
                if f_ is not None:
                    pre, cin = f_
                    lits.remove(L_)
                    tog(*["Tf%d" % q for q in L_])
                    cterms = {"Tf%d" % q for q in L_}
                    break
        elif (sign > 0 and kst["k"] > 0) or (sign < 0 and kst["k"] < 0):
            cin = F8.ONE
            kst["k"] -= sign
            tog("one")
            cterms = {"one"}
        for op in pre:
            _do(c, op)
        if os.environ.get("FC2DBG"):
            print("DBG addw sign %+d row %s kind %s live %d cin %s word %s" % (
                sign, row[0] if row else None, kind, c.live, "lit" if (cin is not None and cin != F8.ONE) else cin,
                "".join("." if w_ is None else ("1" if w_ == F8.ONE else "x") for w_ in src)))
        gvon = bool(o.get("gvirt")) and R[0] is not None
        if gvon:                                       # F3: the guard's in-game value as an XOR of T's wires
            import invsqrt_fw_m7gv as GVM
            st_ = {w_: (frozenset("Tf%d" % q for q in fs_), ng_) for w_, (fs_, ng_) in tstate(row, kind).items()}
            st_[T[nb]] = (frozenset(["s"]), 1 if snot else 0)
            for op in pre:
                if op[0] == "x":
                    st_[op[1]] = (st_[op[1]][0], st_[op[1]][1] ^ 1)
                else:
                    st_[op[2]] = (st_[op[2]][0] ^ st_[op[1]][0], st_[op[2]][1] ^ st_[op[1]][1])
            w0_ = word.get(0)
            p0 = set() if w0_ is None else ({"one"} if w0_ == F8.ONE else
                                            set(st_[w0_][0]) ^ ({"one"} if st_[w0_][1] else set()))
            v0 = set(par) ^ p0 ^ cterms ^ ({"one"} if sign > 0 else set())
            GVM.GV.update(on=True, wire=R[0], form=GVM.solve(st_, v0))
        _Rx = _M3c.ph_real(R)                          # FC8 c0m: no frame X on c0 (write-only top)
        if sign < 0:
            for t in _Rx:
                c.x(t)
        if _M3c.PH:
            assert row is not None and kind == "plain" and o.get("m3"), "c0m: an add into R"
            with _M3c.ph_free(c):
                A.add(c, src, _M3c.ph_target(R), cin=cin)
        else:
            A.add(c, src, R, cin=cin)
        if gvon:
            GVM.GV["on"] = False
        if sign < 0:
            for t in _Rx:
                c.x(t)
        for op in reversed(pre):
            _do(c, op)

    mux = bool(o.get("mux"))
    _MUXSPLIT["q"] = o.get("muxsplit")
    _MUXSPLIT["opt"] = o.get("muxopt")
    if o.get("gvirt"):                                 # F3 (twelfth holder): the virtual guard in the undo games
        import invsqrt_fw_m7gv as GVM
        import invsqrt_fc_narrow as NW_
        GVM.install(NW_)
    _sw1_pre = None                                    # I39-SLOT2 (inv_i39_patch_slot2.py): the table word first
    _r64o = o.get("slot") if o.get("slot") is not None else (o.get("r64") or {})   # R64-P2 (r64_inv_stack_p2.py): the same four options without a slot
    if _r64o.get("wfirst") and (o.get("sw") or {}).get("first"):
        assert not (o.get("sw") or {}).get("hold") or _r64o.get("wfirst_hold"), "wfirst: hold off"
        F8.__dict__["_i39_lend"] = [R[1], cw[0]] if o.get("slot") is not None else [cw[0]]   # R64-P2: no slot: only c0's wire
        F8.__dict__["_i39_stream"] = bool(_r64o.get("wstream"))   # I39-SLOT5 (inv_i39_patch_slot5.py)
        _sw1_pre = _sword_g0(F8, c, o, T, R, s, nb, lits, tog, tstate, par, first=True)
        F8.__dict__["_i39_lend"] = []
        F8.__dict__["_i39_stream"] = False
    if mux:                                            # lin 1 + lin 2 - part 2 of the top row as one mux add
        assert nc == 1
        _rowsfirst = bool(_r64o.get("rowsfirst"))   # I39-SLOT6 (inv_i39_patch_slot6.py)
        F8.__dict__["_i39_rowsfirst"] = _rowsfirst
        if not _rowsfirst:
            _mux_add(F8, c, T, R, s, nb, cubfold, s1)  # (cubfold: s at position 0; s1: none here)
        if cubfold and not s1:
            tog("s")
    else:
        lin1 = {i + nb - 9: T[i] for i in range(nb) if 0 <= i + nb - 9 < nR}
        lin2 = {i + nb - 8: T[i] for i in range(nb) if 0 <= i + nb - 8 < nR}
        if 0 in lin1:
            tog("Tf%d" % (9 - nb))
        if cubfold:                                    # cubfold: +2 s half units as two carry-ins s
            addw(lin1, +1, s, "s")
        else:
            addw(lin1, +1)
        if 0 in lin2:
            tog("Tf%d" % (8 - nb))
        if cubfold:
            addw(lin2, +1, s, "s")
        else:
            addw(lin2, +1)
    _sw1 = None
    _swo = o.get("sw") or {}

    def _cubblock():
        if o.get("cubtab"):                                # cubic as a table of the top k folded bits (signed by s)
            kt, vals = o["cubtab"]
            kt = int(kt)
            nbit = max(int(v).bit_length() for v in vals)
            assert cubfold and mux and nbit == 5, "the table form expects 5 value bits, cubfold and mux"
            zin = [T[nb - kt + i] for i in range(kt)]
            gdfree = bool(o.get("gdearly")) and s1 and bool(o.get("cubdebt")) and not _swo.get("cubfirst")
            if gdfree:                                     # FC2 (fifth holder): nothing after this adds at position 0 (s1),
                for v_ in sorted(par):                     # so the guard (= the XOR of par) is cleared and freed now: the
                    if v_ == "one":                        # table block runs with one more clean wire
                        c.x(Gd)
                    elif v_ == "s":
                        c.cx(s, Gd)
                    else:
                        c.cx(T[int(v_[2:])], Gd)
                c.free_([Gd])
            if not (o.get("sw") or {}).get("cubin"):       # R45-INV-S7B: the cubic is inside the table word
                bw = c.alloc(nbit)
                if o.get("cubdebt"):
                    # forward: table, (b xor s), FC's narrow ripple (carries measured: debts), (b xor s) back, the table bits
                    # X-measured (debts). Explicit undo: table again, debts repaid, FC's narrow undo generator, uncompute.
                    import invsqrt_fc_s8m3 as _M3y     # FC8 c0m (cubic)
                    import invsqrt_fc_narrow as NW
                    from invsqrt_fc2_patch_h1b import _fwd_stream
                    bid = len(c.blocks)
                    c.blocks[bid] = None
                    c.ops.append(("BBEG", bid))
                    _dbg = os.environ.get("FC2DBG")
                    if _dbg:
                        print("DBG table fwd: live with bw %d cap %d par %s" % (c.live, c.cap, sorted(par)))
                    _sc = bool((o.get("sw") or {}).get("sconj"))
                    _csb = _sc and bool((o.get("sw") or {}).get("cinsb"))
                    _cs = s if (_csb or not _sc) else None
                    _cq = [zin[int(i_)] for i_ in (o.get("cubcin") or [])]   # R48-INV-S7C: carry-in = XOR of inputs
                    if _cq:
                        assert _sc and not _csb and s1, "cubcin needs sconj, no cinsb, s1"
                        _cs = _cq[0]
                    emit_table(c, kt, vals, zin, bw)
                    for w in ([] if _sc else bw):
                        c.cx(s, w)
                    if s1:                                     # s1: no guard position; carry-in s at position 1 (= both +s)
                        srcw = list(bw) + ([s] if (o.get("sw") or {}).get("s_out") else [None]) + [None] * (nR - 2 - nbit)
                        Rt = list(R[1:])
                    else:
                        srcw = [None] + list(bw) + [None] * (nR - 1 - nbit)
                        Rt = list(R)
                        tog("s")
                    _r62s = bool((o.get("r62") or {}).get("cubstream")) and _sc   # R62-P1 (r62_inv_word_p1.py)
                    _r62mb = {}

                    def _r62rel(w_):
                        if _r62s and w_ in bw and w_ not in _r62mb:
                            _r62mb[w_] = c.hmr(w_)
                            c.free_([w_])
                    lits_ = [((lambda w_=w_: w_), (lambda w_=w_: _r62rel(w_))) for w_ in srcw]
                    for w in (Rt if _sc else []):
                        c.cx(s, w)
                    if _csb:
                        c.x(s)
                    for w_ in _cq[1:]:
                        c.cx(w_, _cq[0])
                    debts = _fwd_stream(c, NW, lits_, Rt, NW._lit(_cs))
                    for w_ in _cq[1:]:
                        c.cx(w_, _cq[0])
                    if _csb:
                        c.x(s)
                    for w in (Rt if _sc else []):
                        c.cx(s, w)
                    for w in ([] if _sc else bw):
                        c.cx(s, w)
                    mbits = [(_r62mb[w] if w in _r62mb else c.hmr(w)) for w in bw]   # R62-P1 (r62_inv_word_p1.py)
                    c.free_([w for w in bw if w not in _r62mb])
                    c.ops.append(("BEND", bid))
                    save = c.ops
                    c.ops = []
                    _phc = _M3y.ph_free(c).__enter__() if _M3y.PH else None   # FC8 c0m cub
                    _Rt_cr = Rt
                    Rt = _M3y.ph_target(Rt)
                    if _r62mb:                                     # R62-P1 (r62_inv_word_p1.py): the same wires back
                        _take(c, list(bw))
                    else:
                        bw2 = c.alloc(nbit)
                        assert list(bw2) == list(bw), ("table wires", bw2, bw)
                    emit_table(c, kt, vals, zin, bw)
                    for w, mb in zip(bw, mbits):
                        c.z(w, mb)
                    for w in ([] if _sc else bw):
                        c.cx(s, w)
                    Cc = c.cap - c.live
                    if _dbg:
                        print("DBG table undo: live %d Cc %d nR %d" % (c.live, Cc, nR))
                    nt = len(Rt)
                    for w in (Rt if _sc else []):
                        c.cx(s, w)
                    for w in Rt:
                        c.x(w)
                    if _csb:
                        c.x(s)
                    for w_ in _cq[1:]:
                        c.cx(w_, _cq[0])
                    if NW.plan(max(0, nt - 2 - NW.free_prefix(srcw, nt, _cs)), Cc)[0] is not None:
                        NW.game_add(c, srcw, Rt, _cs, debts, Cc)
                    elif s1 and Cc >= 2:                       # F3's mixed form: Cuccaro on the table positions (carries in
                        import invsqrt_fw_c1add as CA          # the table wires), the R32 game on the constant top part
                        if CA.NW is None:
                            CA.NW = NW
                        CA.mixed_add(c, srcw, Rt, _cs, debts, Cc, nbit - 1, int(os.environ.get("C1CCZ", "1")))
                    elif Cc > NW.cuccaro_need(srcw, Rt, _cs):
                        NW.hybrid_add(c, srcw, Rt, _cs, debts, Cc)
                    else:
                        NW.cuccaro_add(c, srcw, Rt, _cs, debts)
                    for w_ in _cq[1:]:
                        c.cx(w_, _cq[0])
                    if _csb:
                        c.x(s)
                    for w in Rt:
                        c.x(w)
                    for w in (Rt if _sc else []):
                        c.cx(s, w)
                    for w in ([] if _sc else bw):
                        c.cx(s, w)
                    if o.get("cubphase") == "staged" and isinstance(_TABPROG["prog"], list):
                        for b_, given, prog in reversed(_TABPROG["prog"]):   # staged measured clear: the last-computed
                            g_ = c.hmr(bw[b_])                 # bit first, its phase repaid by its own stage program
                            emit_phase_cond(c, prog, list(zin) + [bw[d] for d in given], g_)   # (it reads the bits
                        c.free_(bw)                            # still live); 1/2 per AND read by later gates
                    elif o.get("cubphase"):                    # clear the table by measurement; repay each bit's phase by
                        mb2 = [c.hmr(w) for w in bw]           # its own program, conditioned on the outcome (1/2 per AND
                        c.free_(bw)                            # read by later gates; output-only ANDs act as CZ)
                        for k_ in range(nbit):
                            pr = json.load(open(os.path.expanduser(o["cubphase"] % k_)))
                            emit_phase_cond(c, pr, zin, mb2[k_])
                    else:
                        emit_table(c, kt, vals, zin, bw, uncompute=True)
                        c.free_(bw)
                    if _phc is not None:                   # FC8 c0m cub end
                        _phc.__exit__()
                    Rt = _Rt_cr
                    c.blocks[bid] = _M3y.ph_fix(c.ops)
                    c.ops = save
                else:
                    emit_table(c, kt, vals, zin, bw)
                    for w in bw:
                        c.cx(s, w)                             # (b xor s): the signed table, -62 s placed above
                    addw({1 + k_: bw[k_] for k_ in range(nbit)}, +1, s, "s")
                    for w in bw:
                        c.cx(s, w)
                    emit_table(c, kt, vals, zin, bw, uncompute=True)   # uncompute
                    c.free_(bw)


    if _swo.get("cubfirst") and not F8.__dict__.get("_i39_rowsfirst"):   # I39-SLOT6 (inv_i39_patch_slot6.py)
        assert gdlate and _swo.get("sconj")
        _cubblock()
    if (o.get("sw") or {}).get("first"):               # R43-INV-S7: the table word BEFORE the guard exists
        _sw1 = (_sword_g0(F8, c, o, T, R, s, nb, lits, tog, tstate, par, first=True) if _sw1_pre is None
                else _sw1_pre)                         # I39-SLOT2 (inv_i39_patch_slot2.py)
    if gdlate:                                         # FC2: the guard comes to life for the first row word
        Gd = c.alloc(1)[0]
        R[0] = Gd
        for _q in (_sw1 or []):                        # the guard starts as the half-unit bit of that word
            c.cx(T[_q], Gd)
            tog("Tf%d" % _q)

    _m3st = None
    if o.get("m3"):                                   # FC (eighth holder): words in one pass
        import invsqrt_fc_s8m3 as _M3
        _m3st = _M3.begin(c)
    # pair rows, plain words: part 2 of row j unless j is merged; part 1 of row j unless j - 1 is merged
    parts = active_parts(o)
    mlow = {int(k_): int(v_) for k_, v_ in (o.get("mlow") or {}).items()}
    for j in (range(1, nb) if o.get("m3rev") else range(nb - 1, 0, -1)):   # FC8: m3rev
        mine = [(i, p) for (i, jj, p) in parts if jj == j and not ((p - i == j - 8 and j in merge) or
                                                                  (p - i == j - 9 and (j - 1) in merge) or
                                                                  (mux and j == nb - 1 and p - i == j - 8) or
                                                                  (_swo.get("row7") and j == 7 and p - i == j - 8))]
        if not mine:
            continue
        _x0 = bool(o.get("x0")) and j in (8, 9)            # R48-INV-S7C: (0,8) and (0,9) leave position 0
        if _x0:
            assert (0, 0) in mine and nb == 10 and o.get("m3rev") and o.get("m3") and o.get("c0m")
            mine = [q for q in mine if q != (0, 0)]
            for L_ in (frozenset([8]), frozenset([9])):
                if L_ in lits and j == 8:
                    lits.remove(L_)
        idx = sorted({i for i, _ in mine})
        for i in idx:
            c.cx(T[j], T[i])                           # T[i] = x_ij
        groups = {}
        for i, p in mine:
            groups.setdefault(p - i, {})[p] = T[i]     # one word per offset (p - i): part 2 / part 1 / special
        for off_, word in sorted(groups.items(), reverse=not o.get("m3rev")):   # FC8: m3rev order
            if 0 in word:
                i0 = [i for i, p in mine if p == 0 and p - i == off_][0]
                tog("Tf%d" % i0, "Tf%d" % j)
            if _swo.get("s_out") and j == 8 and off_ == j - 9:   # R43: -128 s (with
                assert 7 not in word                   # +64 s in the cubic add)
                word[7] = s
            _sn = bool(_swo.get("cubin")) and j == 7 and off_ == j - 8
            if _sn:                                    # R45-INV-S7B: the cubic is inside the table word with the
                for _q in range(6, nR):                # offset 64 (1 - s) half units: NOT s at positions 6..10 of
                    assert _q not in word              # this subtraction (-(2^11 - 64) = +64 mod 2^11)
                    word[_q] = s
                c.x(s)
            if _x0 and off_ == 0:                          # R48-INV-S7C: row 8.2 (carry-in Tf8) / row 9.1 (carry-in
                assert 0 not in word and not _sn           # Tf0 ? NOT Tf8 : Tf9 on an auxiliary wire)
                if j == 8:
                    addw(word, -1, cin=("x0", T[8]), row=(j, idx), kind="plain")
                else:
                    def _aux(aw, T0=T[0], T8=T[8], T9=T[9]):   # here T[8] = Tf8 xor Tf9, T[0] = Tf0, T[9] = Tf9
                        return ([("X", T8, None), ("ANDC", T0, T8, aw), ("X", T8, None), ("CX", T9, aw, None)],
                                [("CX", T9, aw, None), ("X", T8, None), ("ANDE", T0, T8, aw), ("X", T8, None)])
                    addw(word, -1, cin=("x0", None, _aux), row=(j, idx), kind="plain")
            else:
                addw(word, -1, row=(j, idx), kind="plain", snot=_sn)
            if _sn:
                c.x(s)
        for i in idx:
            c.cx(T[j], T[i])

    if _m3st is not None:
        _M3.merge(c, _m3st)
    F8.__dict__["_i39_gd_early"] = False
    if F8.__dict__.get("_i39_rowsfirst"):                # I39-SLOT6 (inv_i39_patch_slot6.py): mux add and cubic after the rows
        assert s1 and Gd is not None                   # I39-SLOT7 (inv_i39_patch_slot7.py): the guard cleared and freed here
        for v_ in sorted(par):
            if v_ == "one":
                c.x(Gd)
            elif v_ == "s":
                c.cx(s, Gd)
            else:
                c.cx(T[int(v_[2:])], Gd)
        c.free_([Gd])
        F8.__dict__["_i39_gd_early"] = True
        if (o.get("slot") or {}).get("mode") == "muxcin":   # I39-SLOT9 (inv_i39_patch_slot9.py): cubic first, mux add last with carry-in b
            assert not (o.get("muxopt") or {}).get("lo2") and (o.get("muxopt") or {}).get("knowntop") in (None, "c0m"), "muxcin: a mux spec without lo2; knowntop only as c0m"   # R62-P3 (r62_inv_word_p3.py)
            if _swo.get("cubfirst"):
                _cubblock()
            _sl = o["slot"]
            _parm = int(_sl.get("par", 0))
            _bm = c.alloc(1)[0]
            c.cx(L[0], _bm)                            # the slot before the mux add
            c.cx(T[9], _bm)                            # f = Tf9, the mux word's bit at the slot
            c.cx(T[0], _bm)                            # t = Tf0 xor s xor par
            c.cx(s, _bm)
            if _parm:
                c.x(_bm)
            _mux_add(F8, c, T, R, s, nb, cubfold, s1, cin_w=_bm)
            import invsqrt_fw_chiprog as _CPm
            _mp = json.load(open(os.path.expanduser(_sl["uprog"])))
            _mp = _mp.get("acc", _mp.get("prog", _mp))
            _mpg = {"gates": _mp["gates"], "outputs": _mp["outputs"]}
            _mins = [T[i_] for i_ in range(nb)] + [s]
            if _sl.get("bmeas"):                       # I39-SLOT11 (inv_i39_patch_slot11.py): b X-measured; re-made in the mirror
                _bbid = len(c.blocks)
                c.blocks[_bbid] = None
                c.ops.append(("BBEG", _bbid))
                _mbm = c.hmr(_bm)
                c.free_([_bm])
                c.ops.append(("BEND", _bbid))
                _bsave = c.ops
                c.ops = []
                _bw2 = c.alloc(1)[0]
                assert _bw2 == _bm, ("b's wire back", _bw2, _bm)
                _mbud = max(1, c.cap - c.live)
                _msch = _CPm.schedule(_mpg, len(_mins), _mbud)
                assert _msch is not None, ("u(T) program: no schedule within %d temporaries" % _mbud)
                F8.__dict__["_i39_uands"] = _CPm.emit(c, _mpg, _mins, [_bm], _mbud, _msch)   # b = u(T)
                c.cx(T[0], _bm)                        # b = u xor t
                c.cx(s, _bm)
                if _parm:
                    c.x(_bm)
                c.z(_bm, _mbm)                         # the measurement's phase repaid
                c.blocks[_bbid] = c.ops
                c.ops = _bsave
                c.free_([_bm])
            else:
                _mbud = max(1, c.cap - c.live)
                _msch = _CPm.schedule(_mpg, len(_mins), _mbud)
                assert _msch is not None, ("u(T) program: no schedule within %d temporaries" % _mbud)
                F8.__dict__["_i39_uands"] = _CPm.emit(c, _mpg, _mins, [_bm], _mbud, _msch)   # b ^= u(T)
                c.cx(T[0], _bm)                        # b ^= t: zero
                c.cx(s, _bm)
                if _parm:
                    c.x(_bm)
                c.free_([_bm])
        else:
            _mux_add(F8, c, T, R, s, nb, cubfold, s1)
            if _swo.get("cubfirst"):
                _cubblock()

    # merged rows j: part 2 of row j + part 1 of row j + 1 = (e ? ones : 2 X_j), e = Tf_j xor Tf_j+1 (R36's merge)
    drop8 = {tuple(p) for p in o.get("drop8", [])}
    if o.get("sw"):                                    # R43-INV-S7: merged rows 6 and 5 as ONE table word
        _sword(F8, c, o, T, R, s, nb, lits, tog, tstate, par)
    for j in ([] if o.get("sw") else sorted(merge, reverse=True)):
        assert 5 <= j <= nb - 2 and not any(q[1] == j for q in drop8)
        idx = [i for i in range(j) if i + j >= 8 and i >= mlow.get(j, 0)]
        p0 = idx[0] + j - 8                            # position of e (0 unless mlow drops the low pairs)
        for i in idx:
            c.cx(T[j], T[i])                           # T[i] = x_ij
        c.cx(T[j], T[j + 1])                           # T[j + 1] = e_j
        e = T[j + 1]
        c.x(e)
        ors = []
        for i in idx:
            c.x(T[i])
            t = c.and_compute(e, T[i])
            c.x(t)                                     # t = e OR x_ij
            ors.append((i, t))
        c.x(e)
        word = {p0: e}
        for i, t in ors:
            word[i + j - 7] = t
        if p0 == 0:
            tog("Tf%d" % j, "Tf%d" % (j + 1))
        if cubfold and j == min(merge):                # cubfold: -2^(top+1) s (half units) as s at that position
            ps = 6 if o.get("cubtab") else 5
            assert ps not in word
            word[ps] = s
        addw(word, -1, row=(j, idx), kind="merged")
        c.x(e)
        for i, t in reversed(ors):
            c.x(t)
            c.and_erase(e, T[i], t)
            c.x(T[i])
        c.x(e)
        c.cx(T[j], T[j + 1])
        for i in idx:
            c.cx(T[j], T[i])

    # cubic: g (P xor s) added at pos(g); g s subtracted at pos(g) (or, cubfold, -32 s + 2 s placed above)
    cub = o.get("cub", [])
    if cub:
        temps, wp, wm = [], {}, {}
        order = sorted(cub, key=lambda gb: -len(gb[1]))   # AND pieces first (they read the folded bits), then
        for g, bits in order:                             # the single-bit pieces (unfolded in place)
            g = int(g)
            p = (2 * g).bit_length() - 1
            assert (1 << p) == 2 * g and p not in wp, ("cubic weights must be distinct powers of two", g)
            if len(bits) == 1:
                b = T[int(bits[0])]
                c.cx(s, b)                             # Tf_b xor s = the unfolded bit
                wp[p] = b
                temps.append(("lin", b))
            else:
                assert len(bits) == 2
                t = c.and_compute(T[int(bits[0])], T[int(bits[1])])
                c.cx(s, t)
                wp[p] = t
                temps.append(("and", t, int(bits[0]), int(bits[1])))
            wm[p] = s
        assert 0 not in wp
        if cubfold:
            assert sorted(wp) == [1, 2, 3, 4] and merge, "cubfold needs the pieces at 1, 2, 3, 4 (sum 15) and a merge"
        if cubfold and mux:
            addw(wp, +1, s, "s")                       # the second +s (half units) of cubfold
        else:
            addw(wp, +1)
        if not cubfold:
            addw(wm, -1)
        for tk in reversed(temps):
            if tk[0] == "lin":
                c.cx(s, tk[1])
            else:
                c.cx(s, tk[1])
                c.and_erase(T[tk[2]], T[tk[3]], tk[1])

    if not _swo.get("cubfirst"):
        _cubblock()
    assert not lits, ("borrow-in literals not placed", lits)
    assert kst["k"] == 0, ("constant not placed", kst)
    gd_done = ((bool(o.get("gdearly")) and s1 and bool(o.get("cubdebt")) and bool(o.get("cubtab"))
                and not _swo.get("cubfirst")) or bool(F8.__dict__.get("_i39_gd_early")))   # I39-SLOT7 (inv_i39_patch_slot7.py)
    if not gd_done:
        for v_ in sorted(par):                         # the guard bit is the XOR of par: clear it
            if v_ == "one":
                c.x(Gd)
            elif v_ == "s":
                c.cx(s, Gd)
            else:
                c.cx(T[int(v_[2:])], Gd)
    F8.__dict__["_fc2_h1c_dbg"] = dict(Gd=Gd, R=list(R), T=list(T), L=list(L), op=len(c.ops))
    if not gd_done:
        c.free_([Gd])
    _slot = o.get("slot")                              # I39-SLOT (inv_i39_patch_slot.py): the rounding (scaffold: b held)
    if _slot is not None and _slot.get("mode") == "clear":   # I39-SLOT4 (inv_i39_patch_slot4.py): slot := 0 by u(T), then t
        par_ = int(_slot.get("par", 0))
        import invsqrt_fw_chiprog as _CPu
        _up = json.load(open(os.path.expanduser(_slot["uprog"])))
        _up = _up.get("acc", _up.get("prog", _up))
        _upg = {"gates": _up["gates"], "outputs": _up["outputs"]}
        _ins = [T[i_] for i_ in range(nb)] + [s]          # Tf0..9 (T is folded here) and the sign
        _bud = max(1, c.cap - c.live)
        _sch = _CPu.schedule(_upg, len(_ins), _bud)
        assert _sch is not None, ("u(T) program: no schedule within %d temporaries" % _bud)
        F8.__dict__["_i39_uands"] = _CPu.emit(c, _upg, _ins, [L[0]], _bud, _sch)   # slot ^= u(T) -> 0
        c.cx(T[0], L[0])                               # slot := t = T0 xor par (T[0] = Tf0 = T0 xor s)
        c.cx(s, L[0])
        if par_:
            c.x(L[0])
        F8.__dict__["_i39_bw"] = None
    elif _slot is not None and _slot.get("mode") == "muxcin":   # I39-SLOT9 (inv_i39_patch_slot9.py): rounded by the mux add
        par_ = int(_slot.get("par", 0))
        F8.__dict__["_i39_bw"] = None
    elif _slot is not None:
        par_ = int(_slot.get("par", 0))
        bw_ = c.alloc(1)[0]
        c.cx(L[0], bw_)                                # u = the slot after the passes
        c.cx(T[0], bw_)                                # Tf0 = T0 xor s (T is folded here)
        c.cx(s, bw_)
        if par_:
            c.x(bw_)                                   # b = u xor t, t = T0 xor par
        _bid = len(c.blocks)                           # one block: forward = the add on the real wires;
        c.blocks[_bid] = None                          # its undo = the inverse with c0 -> the phantom top
        c.ops.append(("BBEG", _bid))                   # (c0m: c0 is measured before this undo runs)
        _i0 = len(c.ops)
        A.add(c, [bw_], list(L) + [cw[0]])             # slot := t, + (u AND NOT t) above (c0 = top)
        _seg = c.ops[_i0:]
        c.ops.append(("BEND", _bid))
        import invsqrt_fc_kit as _KK
        _und = _KK.Circ.mirror_blocks(_seg, c.blocks)
        if _M3c.PH:
            _und = _M3c.ph_fix([_i39_remap(o_, cw[0], _M3c.PH["P"]) for o_ in _und])
        c.blocks[_bid] = _und
        F8.__dict__["_i39_bw"] = bw_
        if _slot.get("mode") == "upclear":             # I39-SLOT8 (inv_i39_patch_slot8.py): b = u(T) xor t cleared exactly
            import invsqrt_fw_chiprog as _CPv
            _vp = json.load(open(os.path.expanduser(_slot["uprog"])))
            _vp = _vp.get("acc", _vp.get("prog", _vp))
            _vpg = {"gates": _vp["gates"], "outputs": _vp["outputs"]}
            _vins = [T[i_] for i_ in range(nb)] + [s]
            _vb = max(1, c.cap - c.live)
            _vs = _CPv.schedule(_vpg, len(_vins), _vb)
            assert _vs is not None, ("u(T) program: no schedule within %d temporaries" % _vb)
            F8.__dict__["_i39_uands"] = _CPv.emit(c, _vpg, _vins, [bw_], _vb, _vs)   # b ^= u(T)
            c.cx(T[0], bw_)                            # b ^= t (T[0] = Tf0 = T0 xor s)
            c.cx(s, bw_)
            if par_:
                c.x(bw_)
            c.free_([bw_])
            F8.__dict__["_i39_bw"] = None
    c0 = cw[0]
    if nc == 1:                                        # C >> 1 from the threshold rule on the folded T (before T += C)
        c1, c2 = c.alloc(2)
        if o.get("chiphase"):                          # its mirror is a measured clear: c1 (F3's CHI6_C1G reads c2),
            import invsqrt_fw_chiprog as CP            # then c2 (CHI6_C2), phases repaid if the outcome is 1
            ins7 = [T[nb - 4], T[nb - 3], T[nb - 2], T[nb - 1], L[7], L[8], c0]
            bidc = len(c.blocks)
            c.blocks[bidc] = None
            c.ops.append(("BBEG", bidc))
            emit_chi(c, T[nb - 4:nb], L[7], L[8], c0, c1, c2)
            c.ops.append(("BEND", bidc))
            save_ = c.ops
            c.ops = []
            if o.get("chiclr"):                        # F3 (twelfth holder): c2 first (given c1), then c1
                import invsqrt_fw_m7chi as MC
                g2 = c.hmr(c2)
                emit_phase_cond(c, MC.C2G1, ins7 + [c1], g2)
                g1 = c.hmr(c1)
                emit_phase_cond(c, MC.C1, ins7, g1)
            else:
                g1 = c.hmr(c1)
                emit_phase_cond(c, CP.CHI6_C1G, ins7 + [c2], g1)
                g2 = c.hmr(c2)
                emit_phase_cond(c, CP.CHI6_C2, ins7, g2)
            if _M3c.PH:                                # FC8 c0m: c0's last read in the mirror
                c.ops.append(("HMR", _M3c.PH["c0"], _M3c.PH["m0"]))
            c.blocks[bidc] = c.ops
            c.ops = save_
        else:
            emit_chi(c, T[nb - 4:nb], L[7], L[8], c0, c1, c2)
    else:
        c1, c2 = cw[1], cw[2]
    for i in range(nb):
        c.cx(s, T[i])                                  # unfold
    # F3 (twelfth holder): "tc10": T += C on T[:nb] only: the carry into the sign wire is 0 on every input [M
    # invsqrt_fw_m7carry.py, all 3,133,452 inputs], so the top cell is cut (exact)
    A.add(c, [c0, c1, c2], T[:nb] if o.get("tc10") else T)   # T += C (mod 2^(nb + 1))
    # c1, c2 erased by X-measurement; the mirror's explicit undo rebuilds them from T' (threshold rule after the
    # increment, T' folded by its own sign) and repays the phase debts
    bid = len(c.blocks)
    c.blocks[bid] = None
    c.ops.append(("BBEG", bid))
    m1 = c.hmr(c1)
    m2 = c.hmr(c2)
    c.free_([c1, c2])
    c.ops.append(("BEND", bid))
    save = c.ops
    c.ops = []
    r1, r2 = c.alloc(2)
    assert (r1, r2) == (c1, c2), ("explicit undo needs the same wires", (r1, r2), (c1, c2))
    s2 = T[nb]
    for i in range(nb - 4, nb):
        c.cx(s2, T[i])
    emit_chi(c, T[nb - 4:nb], L[7], L[8], c0, c1, c2)
    for i in range(nb - 4, nb):
        c.cx(s2, T[i])
    c.z(c1, m1)
    c.z(c2, m2)
    c.blocks[bid] = c.ops
    c.ops = save
    c.free_([c1, c2])
    _M3c.PH.clear()                                    # FC8 c0m off after the stage
    if _slot is not None:                              # I39-SLOT (inv_i39_patch_slot.py): c0 = T'0 xor slot xor par
        c.cx(T[0], c0)
        c.cx(L[0], c0)
        if par_:
            c.x(c0)
        c.free_([c0])
        return None
    return c0


def apply(F8, cfg):
    done = F8.__dict__.setdefault("_fc2_done", set())
    if "h1c" in done:
        return
    orig = F8.st_main

    def st_main_h1c(c, U, v, cfg_):
        c.tag("H1")
        if opts(cfg_).get("slot") is not None:          # I39-SLOT (inv_i39_patch_slot.py): U = [slot] + y19 = 2 y19
            assert len(U) == 9 + int(opts(cfg_)["nb"]), ("slot: DIV2 must leave 19 wires", len(U))
            U = [c.alloc(1)[0]] + list(U)
            F8.__dict__["_i39_U"] = list(U)
        c0 = stage(F8, c, U, cfg_)
        F8.__dict__["_fc2_h1c_held"] = ([c0] if c0 is not None else
                                        ([F8.__dict__["_i39_bw"]] if F8.__dict__.get("_i39_bw") is not None else []))
        c.tag("MAIN")
        return orig(c, U, v, cfg_)

    F8.st_main = st_main_h1c
    done.add("h1c")


def model_U(y, o):
    """the stage's integer function (= r37_inv_40_ref.stage_ref + off), here for any nb."""
    sys.path.insert(0, HERE)
    import r37_inv_40_ref as R37
    if not o.get("dropparts") and not o.get("mlow"):
        st = dict(nb=int(o["nb"]), cub=o.get("cub", []), K2=int(o["K2"]), drop8=o.get("drop8", []))
        for k_ in ("cubtab", "cin_pairs", "cin_bits"):
            if o.get(k_):
                st[k_] = o[k_]
        U, C = R37.stage_ref(y, st)
        return U + int(o["off"]), C
    return h_circ(y, o)


def h_circ(y, o):
    """the circuit's integer function for any option set: U = y + h + off, C = (L + h) >> 9."""
    nb = int(o["nb"])
    y = np.asarray(y, dtype=np.int64)
    s = (y < 0).astype(np.int64)
    T = y >> 9
    Tf = np.where(s == 1, ~T, T) & ((1 << nb) - 1)
    A = (3 << (nb - 9)) * Tf
    for i, j, p in active_parts(o):
        A = A - ((((Tf >> i) ^ (Tf >> j)) & 1) << p)
    cub = np.zeros_like(Tf)
    for g, bits in o.get("cub", []):
        pr = np.ones_like(Tf)
        for b in bits:
            pr = pr & ((Tf >> int(b)) & 1)
        cub = cub + int(g) * pr
    h = ((A + int(o["K2"])) >> 1) + np.where(s == 1, -cub, cub)
    return y + h + int(o["off"]), ((y & 511) + h) >> 9


def check(src, nsamp, cfgfile, over, seed=11):
    """model vs circuit on sampled inputs + edges: word = FC's ref_main on the model's U; x restored; ancillas 0."""
    src = os.path.abspath(os.path.expanduser(src))
    sys.path.insert(0, src)
    import invsqrt_fw_fcpolrun as W
    F8, K, _ = W.load(src)
    import invsqrt_fc_gen as G
    cfg_in = json.load(open(os.path.expanduser(cfgfile)))
    for k_, v_ in over.items():
        if v_ is None:
            cfg_in.pop(k_, None)
        else:
            cfg_in[k_] = v_
    cfg = W.cfg_for(F8, src, cfg_in)
    o = opts(cfg)
    rng = np.random.default_rng(seed)
    if nsamp <= 0:                                     # every input
        x = np.arange(1, F8.MAX_X + 1, dtype=np.int64)
    else:
        x = np.unique(np.concatenate([rng.integers(1, F8.MAX_X + 1, nsamp), np.arange(1, 300),
                                      np.arange(F8.MAX_X - 300, F8.MAX_X + 1)]))
    c, regs = F8.build_full(dict(cfg))
    sim = K.Sim(len(x), c.next + 2)
    sim.set_word(regs["X"], x)
    nf = regs["nfwd"]
    sim.run(c.ops, 0, nf)
    m = cfg["m"]
    n, k, Q, d, delta = F8.ref_chain(x, m)
    _, q1 = G.ref_div(delta.astype(np.int64) << cfg["F1"], d, F8.a_top(cfg), F8.sched1_of(cfg))
    _, P = G.ref_div(q1 + cfg["c2"] * d, d, F8.a_top(cfg), cfg["sched2"])
    y = -((P + 1) >> 1)
    U, C = model_U(y, o)
    Y = F8.ref_main(U, d, m, cfg["bt"])
    Yc = sim.get_word(regs["word"])
    bad = np.flatnonzero(Yc != Y)
    if len(bad):
        T_ = y >> 9
        print("BAD", len(bad), json.dumps([dict(x=int(x[i]), y=int(y[i]), U=int(U[i]), C=int(C[i]), T=int(T_[i]),
                                               L=int(y[i] & 511), dY=int(Yc[i]) - int(Y[i])) for i in bad[:20]]),
              flush=True)
    sim.run(c.ops, nf, None)
    others = [w for w in range(c.next) if w not in regs["X"]]
    return dict(n=len(x), Y_bad=int((Yc != Y).sum()), x_ok=bool(np.array_equal(sim.get_word(regs["X"]), x)),
                anc_ok=bool(not sim.q[others].any()), exp=c.toffolis_exp(), static=c.toffolis(), peak=c.peak,
                stages=c.stage_counts(), stage_peaks=c.stage_peaks, U_range=[int(U.min()), int(U.max())],
                C=[int(C.min()), int(C.max())])


def prof(src, cfgfile, over):
    """H1' blocks: forward / explicit-undo Toffolis of every narrow or explicit block, and the plain ops between."""
    src = os.path.abspath(os.path.expanduser(src))
    sys.path.insert(0, src)
    import invsqrt_fw_fcpolrun as W
    F8, K, _ = W.load(src)
    cfg_in = json.load(open(os.path.expanduser(cfgfile)))
    cfg_in.update(over)
    cfg = W.cfg_for(F8, src, cfg_in)
    c, regs = F8.build_full(dict(cfg))
    marks = c.tags + [(len(c.ops), "_end", c.live)]
    for (i0, nm, lv), (i1, _, _) in zip(marks[:-1], marks[1:]):
        if nm != "H1":
            continue
        j, plain, rows = i0, [], []
        while j < i1:
            if c.ops[j][0] == "BBEG":
                bid = c.ops[j][1]
                k = j
                while not (c.ops[k][0] == "BEND" and c.ops[k][1] == bid):
                    k += 1
                rows.append((c.toffolis_exp(plain), c.toffolis_exp(c.ops[j:k]), c.toffolis_exp(c.blocks[bid] or [])))
                plain = []
                j = k + 1
                continue
            plain.append(c.ops[j])
            j += 1
        tf = tu = 0.0
        for pl, f, u in rows:
            print("  plain-before %5.1f | block fwd %5.1f undo %5.1f" % (pl, f, u))
            tf += pl + f
            tu += pl + u
        print("  plain-after %5.1f" % c.toffolis_exp(plain))
        print("H1 total fwd %.1f undo %.1f (plain ops mirrored at equal cost)" % (tf + c.toffolis_exp(plain), tu + c.toffolis_exp(plain)))


if __name__ == "__main__":
    if sys.argv[1] == "check":
        print(json.dumps(check(sys.argv[2], int(sys.argv[3]), sys.argv[4], json.loads(sys.argv[5]) if len(sys.argv) > 5 else {})))
    elif sys.argv[1] == "prof":
        prof(sys.argv[2], sys.argv[3], json.loads(sys.argv[4]))
